
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `on-desk`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE IF NOT EXISTS `comentarios` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mensaje` varchar(255) NOT NULL,
  `fecha` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Estructura de tabla para la tabla `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `Register` varchar(1) NOT NULL,
  `Login` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `config`
--

INSERT INTO `config` (`Register`, `Login`) VALUES
('A', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `errores`
--

CREATE TABLE IF NOT EXISTS `errores` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Usuario` varchar(100) NOT NULL,
  `Titulo` varchar(100) NOT NULL,
  `Mensaje` varchar(500) NOT NULL,
  `fecha` varchar(10) DEFAULT NULL,
  `estado` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `invitaciones`
--

CREATE TABLE IF NOT EXISTS `invitaciones` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `type` varchar(1) NOT NULL,
  `usos` int(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE IF NOT EXISTS `mensajes` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `de` varchar(100) NOT NULL,
  `para` varchar(100) NOT NULL,
  `asunto` varchar(100) NOT NULL,
  `mensaje` text NOT NULL,
  `estado` varchar(7) NOT NULL,
  `fechaenvio` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=129 ;


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) NOT NULL,
  `filename` varchar(500) NOT NULL,
  `filetype` varchar(50) NOT NULL,
  `filesize` varchar(100) NOT NULL,
  `owner` varchar(100) NOT NULL,
  `hidden` int(1) NOT NULL,
  `route` varchar(255) NOT NULL,
  `url` varchar(100) NOT NULL,
  `fechasubida` varchar(50) NOT NULL,
  `numdown` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=163 ;

INSERT INTO `uploads` (`ID`, `descripcion`, `filename`, `filetype`, `filesize`, `owner`, `hidden`, `route`, `url`, `fechasubida`, `numdown`) VALUES
(161, '', 'OnDesk Admin Manual.pdf', 'pdf', '600035', 'admin', 1, 'filesuploaded/admin/OnDesk Admin Manual.pdf', 'Y5dNmGej8_bv7Ste0LdO', '01/06/2017', 0),
(162, '', 'OnDesk User Manual.pdf', 'pdf', '380097', 'admin', 1, 'filesuploaded/admin/OnDesk User Manual.pdf', 'CABwQ!J5xHFLrG2hWdst', '01/06/2017', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `usuario` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `profileimg` varchar(255) NOT NULL,
  `admin` varchar(8) NOT NULL DEFAULT 'Free',
  `fecharegistro` varchar(10) DEFAULT NULL,
  `activo` varchar(3) NOT NULL DEFAULT 'ACT',
  `verificada` int(1) NOT NULL,
  `especial` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `usuario` (`usuario`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`ID`, `name`, `usuario`, `email`, `password`, `profileimg`, `admin`, `fecharegistro`, `activo`, `verificada`, `especial`) VALUES
('Admin OnDesk', 'admin', 'mail@example.com', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'filesuploaded/admin/imgprofile/003-people.png', 'Admin', '20-04-2017', 'ACT', 1, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
