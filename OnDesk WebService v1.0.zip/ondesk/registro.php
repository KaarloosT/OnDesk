<?php require 'PHP/newuser.php'; ?>
<?php require 'librerias.php'; ?>

<div class="container">
    <form method="POST" action="" id="registrausuario" name="registro" >
        <center><img src="resources/images/logo.png" style="margin-top: 15vh;" class="img img-responsive"></center>
        <br>
        <center><h4><?php echo $estadoregistros ?></h4></center>
        <input type="hidden" value="<?php echo $estado ?>" id="estado">
        <br>
        <div class="form-group">
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                    <input type="text" class="form-control input-lg" name="username" id="usuario"  placeholder="Usuario" <?php echo $estadoinputs; ?>/>
                    <input type="text" class="form-control input-lg hidden" name="invcod" id="invcod" />

                </div>
                <span id="chivatouser" style="padding: 0px;"></span>
            </div>
        </div>
        <div class="form-group">
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-at" aria-hidden="true"></i></span>
                    <input id="mail" type="text" class="form-control input-lg" name="email" placeholder="Correo Electronico" <?php echo $estadoinputs; ?>/>
                </div>
                <span id="chivatomail" style="padding: 0px;"></span>
            </div>
        </div>
        <div class="form-group">
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock" aria-hidden="true"></i></span>
                    <input id="pass1" type="password" class="form-control input-lg" name="password" placeholder="Contrase&ntilde;a" <?php echo $estadoinputs; ?>/>
                </div>
            </div>
            <span id="chivatopass1" style="padding: 0px;"></span>
        </div>
        <div class="form-group">
            <div class="cols-sm-10">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock" aria-hidden="true"></i></span>
                    <input id="pass2" type="password" class="form-control input-lg" name="rpassword" placeholder="Repite Contrase&ntilde;a" <?php echo $estadoinputs; ?>/>
                </div>
                <span id="chivatopass2" style="padding: 0px;"></span>
            </div>
        </div>
        <div class="checkbox">
            <center><label>Registrandote Aceptas los <a href="#" data-toggle="modal" data-target="#terminos">terminos y condiciones</a> de OnDesk</label></center>
        </div>

        <button id="reg" type="button" class="btn btn-success btn-md" style="width: 100%; padding: 10px;" <?php echo $estadoinputs; ?>>Crear Cuenta</button>
        <br><br>
        <a href="index.php" type="button" class="btn btn-success btn-md" style="width: 100%; padding: 10px;">Volver a Inicio</a>
    </form>
</div>
</body>
</html>

<div id="terminos" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Terminos y condiciones OnDesk</h4>
            </div>
            <div class="modal-body"> 
                <b>INFORMACIÓN RELEVANTE</b><br><br>
                El usuario puede elegir y cambiar la clave para su acceso de administración de la cuenta en cualquier momento, en caso de que se haya registrado. Ondesk.eu no asume la responsabilidad en caso de que el usuario entregue dicha clave a terceras personas
                Ondesk.eu no se hace responsable de la legitimidad de los ficheros que los usuarios almacenen en la plataforma web<br><br>
                <b>USO NO AUTORIZADO</b><br><br>
                En caso de que aplique el usuario tiene totalmente prohibido comercializar parcial o completamente fragmentos de código de OnDesk.eu<br><br>
                <b>PRIVACIDAD</b><br><br>
                ondesk.eu garantiza que la información personal que usted envía cuenta con la seguridad necesaria. Los datos ingresados por usuario o en el caso de requerir una validación de los pedidos no serán entregados a terceros, salvo que deba ser revelada en cumplimiento a una orden judicial o requerimientos legales.
                La suscripción a boletines de correos electrónicos publicitarios es voluntaria y podría ser seleccionada al momento de crear su cuenta.
                OnDesk Online Services reserva los derechos de cambiar o de modificar estos términos sin previo aviso.<br><br>
                <b>BORRAR MI CUENTA</b><br><br>
                ondesk.eu, en el momento de eliminar la cuenta por peticion del usuario o por otros motivos eliminara los ficheros del usuario que se encuentren en estado publico, por otra parte
                todos los ficheros privados que se hayan subido, seran eliminados completamente del sistema de almacenamiento

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>

<div id="invitacion" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false" tabindex="-1">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h5 class="modal-title">Introduce tu invitación</h5>
            </div>
            <div class="modal-body"> 
                <span><?php echo $textomodal ?></span><br><br>
                <input id="codigo" type="text" class="form-control input-md" style="width: 100%;" placeholder="Pega aqui tu invitacion"><br>
                <span id="resulta"></span>
                <input id="comprueba" type="button" class="btn btn-success" style="width: 100%;" value="Comprobar Invitacion">
                <input id="cancela" type="button" class="btn btn-danger" style="width: 100%;" value="Cancelar">
            </div>
        </div>
    </div>
</div>

<script>

    $(document).ready(function () {
        if ($('#estado').val() === 'I') {

            $('#invitacion').modal('toggle');

        }
    });

    //Usuario - Correo - Pass1 - Pass2
    var errores = [2, 2, 2, 2];

    $("#usuario").focusout(function () {
        var usuario = $('#usuario').val();
        if (usuario.length < 5) {

            $('#reg').addClass('disabled');
            $('#chivatouser').html('El usuario debe tener al menos 5 caracteres');
            errores[0] = 2;

        } else {
            $.ajax({
                type: 'POST',
                url: 'AJAX/funciones/compruebauser.php',
                data: 'checkuser=' + $('#usuario').val(),
                success: function (data) {

                    console.log('Usuario ' + data);
                    if (data === 'Ocupado') {

                        $('#reg').addClass('disabled');
                        $('#chivatouser').html('El usuario introducido esta ocupado');
                        errores[0] = 1;
                    } else if (data === 'Disponible') {

                        $('#reg').removeClass('disabled');
                        $('#chivatouser').html('');
                        errores[0] = 0;

                    }
                }
            });
        }
    });


    $('#mail').focusout(function () {
        var emil = $('#mail').val();
        if (emil === "") {

            $('#chivatomail').html('Introduzca un email');
            $('#reg').addClass('disabled');
            errores[1] = 2;

        } else {

            $('#mail').filter(function () {

                var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                if (!emailReg.test(emil)) {
                    console.log('Formato Email No Valido');
                    $('#chivatomail').html('Introduzca un email valido');
                    errores[1] = 1;
                } else {
                    $.ajax({
                        type: 'POST',
                        url: 'AJAX/funciones/compruebamail.php',
                        data: 'checkmail=' + $('#mail').val(),
                        success: function (data) {
                            console.log('Mail ' + data);
                            if (data === 'Ocupado') {

                                $('#reg').addClass('disabled');
                                $('#chivatomail').html('El mail introducido esta ocupado');
                                errores[1] = 1;
                            } else if (data === 'Disponible') {

                                $('#reg').removeClass('disabled');
                                $('#chivatomail').html('');
                                errores[1] = 0;

                            }
                        }
                    });
                }
            });
        }
    });

    $("#pass1").focusout(function () {
        console.log('pass1');
        var pass = $('#pass1').val();
        if (pass.length < 8) {

            console.log('La constraseña debe ser de mas de 8 caracteres');
            $('#chivatopass1').html('La constraseña debe ser de mas de 8 caracteres');

            $('#reg').addClass('disabled');
            errores[2] = 2;

        } else {

            $('#reg').removeClass('disabled');
            $('#chivatopass1').html('');
            errores[2] = 0;

        }
    });

    $("#pass2").focusout(function () {
        console.log('pass2');
        var pass1 = $('#pass1').val();
        var pass2 = $('#pass2').val();
        if (pass2.length >= 8) {

            if (pass1 !== pass2) {

                console.log('Ambas contraseñas deben coincidir');
                $('#chivatopass2').html('Ambas contraseñas deben coincidir');
                $('#reg').addClass('disabled');
                errores[3] = 1;

            } else {

                $('#chivatopass2').html('');
                $('#reg').removeClass('disabled');
                errores[3] = 0;

            }

        } else {

            console.log('La constraseña debe ser de mas de 8 caracteres');
            $('#chivatopass2').html('La constraseña debe ser de mas de 8 caracteres');
            errores[3] = 2;
        }
    });


    $('#comprueba').click(function () {
        $.ajax({
            type: 'POST',
            url: 'AJAX/funciones/comprueinv.php',
            data: 'codeinv=' + $('#codigo').val(),
            success: function (data) {
                if (data === 'valido') {

                    console.log('Invitacion Valida');
                    $('#resulta').html('Invitacion Valida');
                    $('#invitacion').modal('toggle');
                    $('#usuario').removeAttr("disabled");
                    $('#mail').removeAttr("disabled");
                    $('#pass1').removeAttr("disabled");
                    $('#pass2').removeAttr("disabled");
                    $('#reg').removeAttr("disabled");
                    $('#reg').attr('type', 'submit');
                    $('#invcod').val($('#codigo').val());


                } else if (data === 'novalido') {

                    console.log('No le quedan usos');
                    $('#resulta').html('Invitacion sin usos restantes');

                } else if (data === 'error') {

                    console.log('No existe invitacion');
                    $('#resulta').html('No existe una invitacion con este codigo');

                }
            }
        });

    });

    $('#reg').click(function () {

        alert('Muestra errores');
        console.log(errores);
        for (var i = 0; i < errores.length; i++) {
            if (errores [i] === 1) {
                bootstrap_alert.warning('Revise los campos', 'info', 1500);
            }else if( errores[i] === 2){
                
                bootstrap_alert.warning('Rellene todos los campos', 'info', 1500);
            }else{
                
                $('#registrausuario').submit();
                
            }
        }


    });

    $('#cancela').click(function () {

        alert('redirige');
        window.location.replace("index.php");

    });

</script>