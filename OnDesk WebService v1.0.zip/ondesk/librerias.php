<head>
    <title>OnDesk</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" src="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.6.0/clipboard.min.js"></script>
    <script src="js/jquery.ajax-progress.js" type="text/javascript"></script>
    <link href="css/bootstrap-social.css" rel="stylesheet" />
</head>

<style>

    #floating_alert {
        position: absolute;
        top: 60px;
        right: 20px;
        z-index: 5000;
    }


</style>

<script>
    bootstrap_alert = function () {};
    bootstrap_alert.warning = function (message, alert, timeout) {
        $('<div id="floating_alert" class="alert alert-' + alert + ' fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>' + message + '&nbsp;&nbsp;</div>').appendTo('body');


        setTimeout(function () {
            $(".alert").alert('close');
        }, timeout);

    };


</script>