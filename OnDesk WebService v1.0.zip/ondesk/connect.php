<?php

//Introducimos los datos de conexion a la base de datos y realizamos la conexion
$connection = mysqli_connect('localhost', 'root', 'ceroca00');

//Si surge algun problema durante la conexion mostramos un mensaje de error
if (!$connection) {
    die("Database Connection Failed" . mysqli_error($connection));
}

//Selecionamos la base de datos de que vamos a usar y lo asociamos a una variable
$select_db = mysqli_select_db($connection, 'on-desk');
//Si surge algun problema durante la selecion de la base da datos mostramos un mensaje de eror
if (!$select_db) {
    die("Database Selection Failed" . mysqli_error($connection));
}

//--------------------------------------------------------------------------------------------
//--------AQUI CONTROLAMOS LAS ACCIONES DE DESHABILITAR MODULOS DE LA PAGINA------------------
//--------------------------------------------------------------------------------------------

$info = "SELECT * FROM config";

$rinfo = mysqli_query($connection, $info) or die(mysqli_error($connection));

while ($row = mysqli_fetch_array($rinfo)) {

    $registros = $row['Register'];
    $login = $row['Login'];
}


?>
