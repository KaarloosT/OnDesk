<?php
session_start();
require_once('connect.php');

if (isset($_SESSION['usuario'])) {

    $username = $_SESSION['usuario'];

    $numeromensajes = mysqli_query($connection, "SELECT * FROM mensajes WHERE para='$username' and estado='NOREAD'");

    $consulta = "SELECT * FROM user where usuario='$username'";

    $resultadousuario = mysqli_query($connection, $consulta) or die(mysqli_error($connection));

    while ($row = mysqli_fetch_array($resultadousuario)) {

        $nombre = $row["name"];
        $usuario = $row["usuario"];
        $email = $row["email"];
        $account = $row["admin"];
        $fecharegistro = $row["fecharegistro"];
        $imgprofile = $row["profileimg"];
        $espacio = 50;
    }

    $consultaficheros = "SELECT * FROM uploads WHERE owner='$username'";

    $ejecutafichero = mysqli_query($connection, $consultaficheros);

    $numeroficheros = mysqli_num_rows($ejecutafichero);
}
?>


<head>
    <title>OnDesk</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" src="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="http://malsup.github.com/jquery.form.js"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.6.0/clipboard.min.js"></script>
    <script src="js/jquery.ajax-progress.js" type="text/javascript"></script> 
</head>

<style type="text/css">

    .special-img{
        position: relative;
        top: -5px;
        float: left;
        left: -5px;
    }
    .profile-image  {
        padding-top: 0px;
        padding-bottom: 0px;
    }

    .navbar-top {
        margin-bottom: 0px;
        background-color: #0c84e4;
        border-color: #3174b0;
    }
    .navbar-top .navbar-brand {
        color: #ffffff;
    }
    .navbar-top .navbar-brand:hover, .navbar-top .navbar-brand:focus {
        color: #ecf0f1;
    }
    .navbar-top .navbar-text {
        color: #ffffff;
    }
    .navbar-top .navbar-nav > li > a {
        color: #ffffff;
    }
    .navbar-top .navbar-nav > li > a:hover, .navbar-top .navbar-nav > li > a:focus {
        color: #ecf0f1;
        background-color: #3174b0;
    }
    .navbar-top .navbar-nav > .active > a, .navbar-top .navbar-nav > .active > a:hover, .navbar-top .navbar-nav > .active > a:focus {
        color: #ecf0f1;
        background-color: #0c84e4;
    }
    .navbar-top .navbar-nav > .open > a, .navbar-top .navbar-nav > .open > a:hover, .navbar-top .navbar-nav > .open > a:focus {
        color: #ecf0f1;
        background-color: #3174b0;
    }
    .navbar-top .navbar-toggle {
        border-color: #3174b0;
    }
    .navbar-top .navbar-toggle:hover, .navbar-top .navbar-toggle:focus {
        background-color: #3174b0;
    }
    .navbar-top .navbar-toggle .icon-bar {
        background-color: #ffffff;
    }
    .navbar-top .navbar-collapse,
    .navbar-top .navbar-form {
        border-color: #ffffff;
    }
    .navbar-top .navbar-link {
        color: #ffffff;
    }
    .navbar-top .navbar-link:hover {
        color: #ecf0f1;
    }

    @media (max-width: 767px) {
        .navbar-top .navbar-nav .open .dropdown-menu > li > a {
            color: #ffffff;
        }
        .navbar-top .navbar-nav .open .dropdown-menu > li > a:hover, .navbar-top .navbar-nav .open .dropdown-menu > li > a:focus {
            color: #ecf0f1;
        }
        .navbar-top .navbar-nav .open .dropdown-menu > .active > a, .navbar-top .navbar-nav .open .dropdown-menu > .active > a:hover, .navbar-top .navbar-nav .open .dropdown-menu > .active > a:focus {
            color: #ecf0f1;
            background-color: #0c84e4;
        }
    }


</style>

<div class="navbar navbar-static-top masthead navbar-top" role="navigation">

    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" >
                <span class="fa fa-sign-in"></span>
            </button>

            <button type="button" class="navbar-toggle" >
                <span class="fa fa-user"></span>
            </button>

            <a class="navbar-brand" href="#"><img src="resources/images/logo.png" height="20px"></a>



        </div>
        <div class = "collapse navbar-collapse navbar-ex1-collapse" id = "top-nav">
            <ul class = "nav navbar-nav">

            </ul>
            <ul class = "nav navbar-nav navbar-right hidden-xs">
<?php if (isset($_SESSION['usuario'])) { ?>
                    <li class = "active hidden-xs"><a href = "#" data-toggle = "modal" data-target = "#reportaerror"><i class = "fa fa-bug"></i> Informar Error</a></li>
                    <li class = "active hidden-xs"><a href = "archivos-bs.php"><i class = "glyphicon glyphicon-user"></i> Mi Cuenta</a></li>
<?php } else { ?>
                    <li class = "active hidden-xs"><a href = ""><i class = "fa fa-user"></i> Registrarse</a></li>
                    <li class = "active hidden-xs"><a href = "#"><i class = "fa fa-sign-in"></i> Iniciar Sesion</a></li>
<?php } ?>
            </ul>
        </div>
    </div>


</div>	


<div id="reportaerror" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Vaya! Parece que has encontrado con un fallo</h4>
            </div>
            <div class="modal-body">
                <form method="POST" action="senderror.php" id="fo3" name="fo3">
                    <div class="form-group">
                        <input name="titulo" type="text" class="form-control" id="ertitulo" placeholder="Resumen Error" required="">
                        <input name="usuarioer" type="text" class="form-control hidden" id="erusuario" required="" value="<?php echo $usuario ?>">
                    </div>
                    <div class="form-group">
                        <textarea name="mensaje" class="form-control" rows="5" id="ermensaje" style="overflow:auto;resize:none;height:200px;" maxlength="500" minlength="100" placeholder="Explicanos en 500 caracteres en que consiste el error" required=""></textarea>
                    </div>
                    <div id="result"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                <button class="btn btn-success" type="submit" name="enviar">Enviar</button>
                </form>
            </div>

        </div>

    </div>
</div>
<?php if ($account == 'Admin') { ?>
    <input class="hidden" value="<?php echo $login ?>" id="estadologinactual">
    <input class="hidden" value="<?php echo $registros ?>" id="estadoregistroactual">
    <div id="managesite" class="modal fade" role="dialog" >
        <div class="modal-dialog" >
            <div class="modal-content" style="background-color: whitesmoke">
                <div class="modal-body">
                    <form method="POST" id="modificarestados">
                        <table border='0' style="width: 100%;">
                            <tr>
                                <td style="width: 50%">
                                    <div style="width:100%; background-color: whitesmoke; height: 100%;">
                                        <center>
                                            <br><span class="fa fa-user fa-5x"></span><br>
                                            <span>Registros</span><br><br>
                                            <div class="input-group">
                                                <div id="radioBtn" class="btn-group">
                                                    <a class="btn btn-default btn-md" id="registroa"><span class="fa fa-unlock-alt fa-2x"></span></a>
                                                    <a class="btn btn-primary btn-md" id="registroc"><span class="fa fa-lock fa-2x"></span></a>
                                                    <a class="btn btn-default btn-md" id="registroi"><span class="fa fa-ticket fa-2x"></span></a>
                                                </div>

                                                <input type="text" id="estadoregistro" name="estadoregistro" class="form-control hidden" placeholder="" value="I">
                                            </div>
                                            <br>
                                            <br>
                                        </center>
                                    </div>
                                </td>
                                <td style="width: 50%">
                                    <div style="width:100%; background-color: whitesmoke; height: 100%;">
                                        <center>
                                            <br><span class="fa fa-sign-in fa-5x"></span><br>
                                            <span>Inicios de Sesion</span><br><br>
                                            <div class="input-group" >
                                                <div id="radioBtn" class="btn-group">
                                                    <a class="btn btn-default btn-md" id="logina"><span class="fa fa-unlock-alt fa-2x"></span></a>
                                                    <a class="btn btn-primary btn-md" id="loginc"><span class="fa fa-lock fa-2x"></span></a>
                                                </div>
                                                <input type="text" id="estadologin" name="estadologin" class="form-control hidden" placeholder="" value="A">
                                            </div>
                                            <br>
                                            <br>
                                        </center>
                                    </div>
                                </td>                        
                            </tr>
                            <tr>
                            <center>
                                <td style="width: 50%;"><button class="btn btn-md btn-success" style="width: 100%;" id="actualizaestado">Guardar</button></td>
                                <td style="width: 50%;"><button class="btn btn-md btn-danger" data-dismiss="modal" id="cancelaestado" style="width: 100%;">Cancelar</button></td>
                            </center>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>

        </div>
    </div>
<?php } ?>


<script>

    $('#manage').click(function () {

        var login = $('#estadologinactual').val();

        if (login === 'A') {

            $('#logina').trigger("click");

        } else if (login === 'C') {

            $('#loginc').trigger("click");

        }

        var registro = $('#estadoregistroactual').val();

        if (registro === 'A') {

            $('#registroa').trigger("click");

        } else if (registro === 'C') {

            $('#registroc').trigger("click");

        } else if (registro === 'I') {

            $('#registroi').trigger("click");

        }

    });

    //Formulario del reporte de errores |    
    $('#fo3').submit(function () {
        $.ajax({
            type: 'POST',
            url: $(this).attr('action'),
            data: $(this).serialize(),
            success: function (data) {
                $('#ertitulo').val("");
                $('#ermensaje').val("");
                $('#reportaerror').modal('toggle');
                bootstrap_alert.warning('Gracias por informarnos del error!', 'warning', 1500);
            }
        });

        return false;
    });

    bootstrap_alert = function () {};
    bootstrap_alert.warning = function (message, alert, timeout) {
        $('<div id="floating_alert" class="alert alert-' + alert + ' fade in"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>' + message + '&nbsp;&nbsp;</div>').appendTo('body');


        setTimeout(function () {
            $(".alert").alert('close');
        }, timeout);

    };

    $('#logina').click(function () {
        $('#logina').removeClass('btn-default');
        $('#logina').addClass('btn-primary');
        $('#loginc').addClass('btn-default');
        $('#loginc').removeClass('btn-primary');
        $('#estadologin').val('A');
        console.log('Logins Abiertos');
    });

    $('#loginc').click(function () {
        $('#loginc').removeClass('btn-default');
        $('#loginc').addClass('btn-primary');
        $('#logina').addClass('btn-default');
        $('#logina').removeClass('btn-primary');
        $('#estadologin').val('C');
        console.log('Logins Cerrados');
    });

    $('#registroa').click(function () {
        $('#registroa').removeClass('btn-default');
        $('#registroa').addClass('btn-primary');
        $('#registroc').addClass('btn-default');
        $('#registroc').removeClass('btn-primary');
        $('#registroi').addClass('btn-default');
        $('#registroi').removeClass('btn-primary');
        $('#estadoregistro').val('A');
        console.log('Registros Abiertos');
    });

    $('#registroc').click(function () {
        $('#registroc').removeClass('btn-default');
        $('#registroc').addClass('btn-primary');
        $('#registroa').addClass('btn-default');
        $('#registroa').removeClass('btn-primary');
        $('#registroi').addClass('btn-default');
        $('#registroi').removeClass('btn-primary');
        $('#estadoregistro').val('C');
        console.log('Registros Cerrados');
    });

    $('#registroi').click(function () {
        $('#registroi').removeClass('btn-default');
        $('#registroi').addClass('btn-primary');
        $('#registroc').addClass('btn-default');
        $('#registroc').removeClass('btn-primary');
        $('#registroa').addClass('btn-default');
        $('#registroa').removeClass('btn-primary');
        $('#estadoregistro').val('I');
        console.log('Registros con Invitacion');
    });

    $('#modificarestados').submit(function () {
        var formdata = new FormData($(this)[0]);
        $.ajax({
            type: 'POST',
            cache: false,
            contentType: false,
            processData: false,
            url: 'AJAX/admin/updatesite.php',
            data: formdata,
            success: function (data) {
                $('#estadoregistroactual').val($('#estadoregistro').val());
                $('#estadologinactual').val($('#estadologin').val());
                bootstrap_alert.warning(data, 'warning', 2500);
                $('#managesite').modal('toggle');

            }
        });
        return false;
    });



</script>