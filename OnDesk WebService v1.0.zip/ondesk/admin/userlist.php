<div class = "" style="width: 100%;">
    <table class = "table" border="0">

        <tr>
            <th class="hidden-xs"><center>Nombre</center></th><!--Nombre del archivo -->
        <th class=""><center>Usuario</center></th><!--Tamaño del fichero -->
        <th class="hidden-xs"><center>Correo</center></th><!--Extension del fichero -->
        <th class="hidden-xs"><center>Fecha Registro</center></th><!--Fecha Subida de archivo -->
        <th class="hidden-xs"><center>Tipo de Cuenta</center></th><!--Visibilidad Publica del fichero-->
        <th class="hidden-xs"><center>Estado cuenta</center></th><!--Visibilidad Publica del fichero-->
        <th class=""><center>Acciones</center></th><!--Acciones sobre el fichero-->
        </tr>
        <?php
        $sql = mysqli_query($connection, "SELECT * FROM user");

        if (mysqli_num_rows($sql) == 0) {
            echo '<tr><td colspan="8">No has subido ningun archivo</td></tr>';
        } else {
            $no = 1;
            while ($row = mysqli_fetch_assoc($sql)) {
                ?>

                <tr>
                    <td class="hidden-xs"><center id="nombreusuario<?php echo $row['ID'] ?>"><?php echo $row['name']; ?></center></td>
                <td><center id="username<?php echo $row['ID'] ?>"><?php echo $row['usuario']; ?></center></td>
                <td class="hidden-xs"><center id="correousuario<?php echo $row['ID'] ?>"><?php echo $row['email']; ?></center></td>
                <td class="hidden-xs"><center><?php echo $row['fecharegistro']; ?></center></td>

                <td class="hidden-xs">
                <center>
                    <?php if ($row['admin'] == 'Admin') { ?>
                        <output><span class="label label-warning" id="cuentausuario<?php echo $row['ID'] ?>" style="padding: 5px;">Admin</span></output>
                    <?php } else { ?>
                        <output><span class="label label-info" id="cuentausuario<?php echo $row['ID'] ?>" style="padding: 5px;">Usuario</span></output>
                        <?php
                    }
                    ?>
                </center>
                </td>

                <td class="hidden-xs">
                <center>
                    <?php if ($row['activo'] == 'ACT') { ?>
                        <output><span class="label label-info" id="estadousuario<?php echo $row['ID'] ?>" style="padding: 5px;">Activa</span></output>
                    <?php } else { ?>
                        <output><span class="label label-danger" id="estadousuario<?php echo $row['ID'] ?>" style="padding: 5px;">Bloqueada</span></output>
                        <?php
                    }
                    ?>
                </center>
                </td>





                <td>
                <center>

                    <a id="<?php echo $row['ID']; ?>" onclick="edita(this.id)" title="Editar Propiedades" class="btn btn-primary btn-md"><span class="fa fa-gears" aria-hidden="true"></span></a>

                    <a id="<?php echo $row['ID']; ?>" onclick="mail(this.id)" title="Enviar Mensaje" class="btn btn-info btn-md"><span class="fa fa-envelope" aria-hidden="true"></span></a>

                    <a id="<?php echo $row['ID']; ?>" onclick="deleteuser(this.id)" title="Borrar Usuario" class="btn btn-danger btn-md"><span class="fa fa-trash" aria-hidden="true"></span></a>

                </center>
                </td>
                </tr>


                <?php
                $no++;
            }
        }
        ?>   
    </table>
</div>


<div id = "ShowUser" class = "modal fade" role = "dialog" style="height: 500px; padding-top: 5%; overflow-y:hidden; overflow-x:hidden;">
    <div class = "modal-dialog">
        <div class = "modal-content">
            <div class = "modal-header">
                <span>Editar datos de usuario</span>
            </div>
            <div class = "modal-body">
                <center>
                    <div style="width: 100%;">
                        <form id="modificausuario" method="POST">
                            <table border="0" style="width: 80%;" class="">
                                <tr>
                                    <td> 
                                        <div style="width: 100%;">
                                            <input type="hidden" id="idusr" name="idusr">
                                            <input type="text" id="usernombre" name="usrnm" class="form-control" placeholder="Nombre"/>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td> 
                                        <br>
                                        <div style="width: 100%;">
                                            <input type="text" id="usermail" name="usermail" class="form-control " placeholder="Correo"/>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td> 
                                        <br>
                                        <table border="0" style="width: 100%;">
                                            <tr>
                                                <td>
                                                    <div class="input-group" style="float: right; padding-right: 2px">
                                                        <div id="radioBtn" class="btn-group" style="width:150px; ">
                                                            <a class="btn btn-default btn-md" id="tusr" style="width: 50%">Usuario</a>
                                                            <a class="btn btn-primary btn-md" id="tadmin" style="width: 50%">Admin</a>
                                                        </div>
                                                        <input type="text" id="accountype" name="accountype" class="form-control hidden disabled" placeholder="" value="">
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="input-group" style="float: left; padding-left: 2px;">
                                                        <div id="radioBtn" class="btn-group" style="width: 150px; ">
                                                            <a class="btn btn-default btn-md" id="sact">Activa</a>
                                                            <a class="btn btn-primary btn-md" id="sdec">Bloqueda</a>
                                                        </div>
                                                        <input type="text" id="accountest" name="accountest" class="form-control hidden disabled" placeholder="" value="L">
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3"><br><center><input type="submit" class="btn btn-md btn-success" value="Guardar"  style="width: 40%;"/>&nbsp;<input type="button" data-dismiss="modal"  style="width: 40%;" class="btn btn-md btn-danger" value="Cancelar"/></center></td>
                                </tr>
                            </table>

                        </form>
                    </div>
                </center>
            </div>
        </div>
    </div>
</div>

<div id = "MailUser" class = "modal fade" role = "dialog" style="height: 500px; padding-top: 5%; overflow-y:hidden; overflow-x:hidden;">
    <div class = "modal-dialog">
        <div class = "modal-content">
            <form method="POST" id="adminmail">
                <div class = "modal-header">
                    <span>Enviar mensaje a <b><span id="usuariomensaje"></span></b></span>
                </div>
                <div class = "modal-body">
                    <form method="POST" id="messagesend">
                        <div class="form-group">
                            <input type="text" class="hidden" value="Administracion OnDesk" name="remitente">
                            <input type="text" class="hidden" value="" id="destinatario" name="destinatario">
                            <input type="text" id="uasu" name="asunto" class="form-control" placeholder="Asunto">
                        </div>
                        <textarea class="form-control" id="umsg" name="mensaje" placeholder="Mensaje" style="overflow:auto;resize:none;height:200px;"></textarea>
                        <div class="btn-send">
                            <br>
                            <center>
                                <button class="btn btn-success btn-md" name="enviar" type="submit" style="width: 48%;"><span class="glyphicon glyphicon-send"></span> Enviar</button>
                                <button class="btn btn-warning btn-md" name="enviar" type="button" data-dismiss="modal" style="width: 48%;"><span class="glyphicon glyphicon-remove"></span> Cancelar</button>
                            </center>
                        </div>
                    </form>
                </div>
            </form>

        </div>
    </div>
</div>

<div id = "ConfirmDelete" class = "modal fade" role = "dialog" style="height: 500px; padding-top: 10%; overflow-y:hidden; overflow-x:hidden;">
    <div class = "modal-dialog">
        <div class = "modal-content">
            <form method="POST" id="deluser">

                <center><h4>Estas seguro?</h4></center>

                <center><img src="../resources/images/pregunta.PNG"></center>

                <center><h4>Esta accion no se puede deshacer</h4></center>

                <input type="hidden" id="borrausuario" name="borrausuario">
                <br>
                <center><button type="submit" id="reg" name="inicio" class="btn btn-danger btn-md" style="width: 30%; padding: 10px;">Borrar</button>
                    <a href="#" class="btn btn-warning btn-md" data-dismiss="modal" role="button" style="width: 30%; padding: 10px;">Cancelar</a></center>
            </form>
        </div>
    </div>
</div>

<script>

    function edita(userid) {

        $('#ShowUser').modal({show: true});
        var uname = $('#nombreusuario' + userid).html();
        $('#usernombre').val(uname);
        var umail = $('#correousuario' + userid).html();
        $('#usermail').val(umail);
        var tipoc = $('#cuentausuario' + userid).html();
        if (tipoc === 'Admin') {
            $("#tadmin").trigger("click");
        } else {
            $("#tusr").trigger("click");
        }
        var estadoc = $('#estadousuario' + userid).html();
        if (estadoc === 'Activa') {
            $("#sact").trigger("click");
        } else {
            $("#sdec").trigger("click");
        }
        $('#idusr').val(userid);

    }

    function mail(userid) {

        $('#MailUser').modal({show: true});
        var uname = $('#nombreusuario' + userid).html();
        $('#usernombre').val(uname);
        $('#usuariomensaje').html(uname);
        var usr = $('#username' + userid).html();
        $('#destinatario').val(usr);


    }

    function deleteuser(userid) {

        $('#ConfirmDelete').modal({show: true});
        $('#borrausuario').val(userid);

    }

    $('#sact').click(function () {
        $('#sact').removeClass('btn-default');
        $('#sact').addClass('btn-primary');
        $('#sdec').addClass('btn-default');
        $('#sdec').removeClass('btn-primary');
        $('#accountest').val('ACT');
        console.log('Cuenta Activada');
    });

    $('#sdec').click(function () {
        $('#sdec').removeClass('btn-default');
        $('#sdec').addClass('btn-primary');
        $('#sact').addClass('btn-default');
        $('#sact').removeClass('btn-primary');
        $('#accountest').val('DEC');
        console.log('Cuenta Bloqueada');
    });

    $('#tusr').click(function () {
        $('#tusr').removeClass('btn-default');
        $('#tusr').addClass('btn-primary');
        $('#tadmin').addClass('btn-default');
        $('#tadmin').removeClass('btn-primary');
        $('#accountype').val('Free');
        console.log('Cuenta Free');
    });

    $('#tadmin').click(function () {
        $('#tadmin').removeClass('btn-default');
        $('#tadmin').addClass('btn-primary');
        $('#tusr').addClass('btn-default');
        $('#tusr').removeClass('btn-primary');
        $('#accountype').val('Admin');
        console.log('Cuenta Admin');
    });

    $('#adminmail').submit(function () {
        $.ajax({
            type: 'POST',
            url: 'AJAX/admin/adminmsg.php',
            data: $(this).serialize(),
            success: function (data1) {
                $('#MailUser').modal('toggle');
                bootstrap_alert.warning('Mensaje enviado', 'success', 1500);
            }
        });

        return false;
    }); //Envia un nuevo mensajes con los datos que introduce el usuario

    $('#modificausuario').submit(function () {
        var formdata = new FormData($(this)[0]);
        $.ajax({
            type: 'POST',
            url: 'AJAX/admin/editusrad.php',
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            success: function (id) {
                $('#ShowUser').modal('toggle');
                bootstrap_alert.warning('Usuario Modificado Correctamente', 'success', 1500);
                var usuario = $('#usernombre').val();
                $('#nombreusuario' + id).html(usuario);
                var mail = $('#usermail').val();
                $('#correousuario' + id).html(mail);
                var estado = $('#accountest').val();

                if (estado === 'ACT') {

                    $('#estadousuario' + id).removeClass('label-danger');
                    $('#estadousuario' + id).addClass('label-info');
                    $('#estadousuario' + id).html('Activa');

                } else {

                    $('#estadousuario' + id).removeClass('label-info');
                    $('#estadousuario' + id).addClass('label-danger');
                    $('#estadousuario' + id).html('Bloqueada');

                }

                var tipo = $('#accountype').val();

                if (tipo === "Admin") {

                    $('#cuentausuario' + id).removeClass('label-info');
                    $('#cuentausuario' + id).addClass('label-warning');
                    $('#cuentausuario' + id).html('Admin');

                } else {

                    $('#cuentausuario' + id).removeClass('label-warning');
                    $('#cuentausuario' + id).addClass('label-info');
                    $('#cuentausuario' + id).html('Usuario');

                }
            }
        });

        return false;
    }); //Envia un nuevo mensajes con los datos que introduce el usuario

    $('#deluser').submit(function () {
        $.ajax({
            type: 'POST',
            url: 'AJAX/admin/deluserad.php',
            data: $(this).serialize(),
            success: function (data1) {
                $('#ConfirmDelete').modal('toggle');
                bootstrap_alert.warning(data1, 'success', 1500);
            },
            error: function (req) {
                alert('Error: ' + req.status);
            }
        });
        return false;
    }); //Envia un nuevo mensajes con los datos que introduce el usuario


</script>