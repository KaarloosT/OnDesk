
<?php
include("connection.php");


$ID = $_GET['ID'];
			$sql = mysqli_query($koneksi, "SELECT * FROM user WHERE ID='$ID'");
			if(mysqli_num_rows($sql) == 0){
				header("Location: index.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			}
			if(isset($_POST['save'])){
				
				$name		     = $_POST['name'];
				$username		 = $_POST['username'];
				$email			 = $_POST['email'];
				$admin			 = $_POST['admin'];
				$activo			 = $_POST['activo'];
				$password		 = $_POST['passwod'];
				
				
				
				
				
				$update = mysqli_query($koneksi, "UPDATE user SET name='$name', usuario='$username', email='$email', admin='$admin', activo='$activo' WHERE ID='$ID'") or die(mysqli_error());
				if($update){
					header("Location: edit.php?ID=".$ID."&pesan=OK");
				}else{
					echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data gagal disimpan, silahkan coba lagi.</div>';
				}
			}
			
			if(isset($_GET['pesan']) == 'OK'){
				echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Los datos se han actualizado correctamente</div>';
			}




?>
				<ul>
					<li><a href="index.php">Listado Usuarios</a></li>
					<li><a href="add.php">Añadir Usuario</a></li>
				</ul>
	
	
	
	<div class="container">
		<div class="content">
			<h2>Datos de Usuario &raquo; Editar Datos de <?php echo $row ['usuario']; ?></h2>
			<hr />
			
			
			<form class="form-horizontal" action="" method="post">
				<div class="form-group">
					<label class="col-sm-3 control-label">Nombre Completo</label>
					<div class="col-sm-4">
						<input type="text" name="name" value="<?php echo $row ['name']; ?>" class="form-control" placeholder="Nombre Completo" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Nombre de usuario</label>
					<div class="col-sm-4">
						<input type="text" name="username" value="<?php echo $row ['usuario']; ?>" class="form-control" placeholder="Nombre de Usuario" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Correo Electronico</label>
					<div class="col-sm-4">
						<input type="text" name="email" value="<?php echo $row ['email']; ?>" class="form-control" placeholder="Correo Electronico" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Administrador</label>
					<div class="col-sm-2">
						<select name="admin" class="form-control">
							<option value=""> - Tipo de Usuario - </option>
							<option value="Admin">Administrador</option>
							<option value="Free">Free</option>
                            <option value="Premium">Premium</option>
						</select>
					</div>
                    <div class="col-sm-3">
                    <b>Tipo de usuario actual :</b> <span class="label label-success"><?php echo $row['admin']; ?></span>
				    </div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-3 control-label">Disponibilidad de la cuenta</label>
					<div class="col-sm-2">
						<select name="activo" class="form-control">
							<option value="">- Activo / Inactvio -</option>
                            <option value="ACT">Cuenta Activa</option>
							<option value="DES">Cuenta no Activa</option>
						</select> 
					</div>
                    <div class="col-sm-3">
                    <b>Disponibilidad de la cuenta :</b> <span class="label label-info"><?php echo $row['activo']; ?></span>
				    </div>
                </div>
				<div class="form-group">
					<label class="col-sm-3 control-label">&nbsp;</label>
					<div class="col-sm-6">
						<input type="submit" name="save" class="btn btn-sm btn-primary" value="Guardar">
						<a href="index.php" class="btn btn-sm btn-danger">Inicio</a>
					</div>
				</div>
			</form>
		</div>
	</div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	</body>
</html>


$ID = $_POST['ID'];