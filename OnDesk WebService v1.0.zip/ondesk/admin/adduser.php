<?php

session_start();
include("../connect.php");

if (isset($_SESSION['usuario'])) {

    $username = $_SESSION['usuario'];
    $consulta = "SELECT * FROM user where usuario='$username'";
    $resultado = mysqli_query($connection, $consulta) or die(mysqli_error($connection));

    while ($row = mysqli_fetch_array($resultado)) {

        $nombre = $row["name"];
        $usuario = $row["usuario"];
        $account = $row["admin"];
        $act = $row['activo'];
    }



    if (isset($_POST['adduser'])) {

        $username = $_POST['username'];
        $email = $_POST['email'];
        $pass1 = $_POST['pass1'];
        $pass2 = $_POST['pass2'];
        $name = $_POST['name'];
//		$date = date("d-m-Y");

        if ($pass1 == $pass2) {

            $password = md5($pass1);
        }

        $consultauser = "SELECT * FROM user WHERE usuario='$username'";

        $checkuser = mysql_query($connection, $consultauser);




        if (mysqli_num_rows($checkuser) == 0) {

            $query = "INSERT INTO user (name, usuario, email, password) VALUES ('$name', '$username', '$email', '$password')";
            $result = mysqli_query($connection, $query);

            if ($result) {

                header('Location: index.php');
            } else {

                header('Location: ../main.php');
            }
        } else {

            header('Location: ../main.php');
        }
    }




    if ($account == "Admin") {
        ?>



        <title>OnDesk WebService</title>
        <h1>OnDesk Admin</h1>

        <hr />
        <ul>
            <li><a href="index.php">Listado Usuarios</a></li>
            <li><a href="adduser.php">Añadir Usuario</a></li>
            <li><a href="mensajes.php">Ver mensajes recibidos</a> - NO FUNCIONA</li>
            <li><a href="../main.php">Salir Panel Admin</a></li>
        </ul>

        <h2>Añadir Usuario</h2>
        <hr />


        <form action="" method="post">

            Nombre
            <br>
            <input type="text" name="name" placeholder="nombre" required>
            <br>

            Nombre de usuario
            <br>
            <input type="text" name="username" placeholder="Nombre de Usuario" required>
            <br>

            Correo Electronico
            <br>
            <input type="text" name="email" placeholder="example@yourdomain.com" required>
            <br>

            Password
            <br>
            <input type="password" name="pass1" placeholder="Contraseña" required>
            <br>

            Repite Password
            <br>
            <input type="password" name="pass2" placeholder="Repite Contraseña" required>
            <br>

            <!--Tipo de Cuenta - [Admin / Free / Premium]
            <br>
                            <input type="text" name="admin" placeholder="Tipo de Cuenta" required>
                            <br>-->



            <input type="submit" name="adduser" value="Guardar">
            <br>
            <a href="index.php">Inicio</a>

        </form>


        <?php

    } else {

        header('Location: ../main.php');
    }
}
?>
