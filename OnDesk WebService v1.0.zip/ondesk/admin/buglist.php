
<style type="text/css">

    body {
        background-color:#F7F7F7;
        font-family: 'Open Sans', sans-serif;
    }
    /*Navbar*/
    .navbar-default {
        background-color:#fff;
        border-bottom-color:#E3E3E3;
    }
    .navbar-default .navbar-nav>.active>a, 
    .navbar-default .navbar-nav>.active>a:hover, 
    .navbar-default .navbar-nav>.active>a:focus{
        background-color:transparent!important;
    }
    .navbar-default .btn-compose {
        padding-right:10px;
        border-right:1px solid #F0F0F0;
    }
    /*Forms setup*/

    .float-label{
        font-size:10px;
    }

    /*Content Container*/
    .content-container {
        background-color:#fff;
        padding:35px 20px;
        margin-bottom:20px;
    }
    h1.content-title{
        font-size:32px;
        font-weight:300;
        text-align:center;
        margin-top:0;
        margin-bottom:20px;
        font-family: 'Open Sans', sans-serif!important;
    }
    /*Compose*/
    .btn-send{
        text-align:center;
        margin-top:20px;
    }
    /*mail list*/

    ul.mail-list{
        padding:0;
        margin:0;
        list-style:none;
        margin-top:30px;
    }
    ul.mail-list li a{
        display:block;
        border-bottom:1px solid #CFCFCF;
        padding:20px;
        text-decoration:none;
    }

    ul.mail-list li a:hover{
        background-color:#DBF9FF;
    }
    ul.mail-list li span{
        display:block;
    }
    ul.mail-list li span.mail-sender{
        font-weight:600;
        color:#8F8F8F;
    }
    ul.mail-list li span.mail-subject{
        color:#8C8C8C;
    }
    ul.mail-list li span.mail-message-preview{
        display:block;
        color:#A8A8A8;
    }

    .estiloasu{

        font-weight: bold;

    }

</style>
<div class="container">
    <div class="content-container clearfix">
        <div class="col-md-12">
            <h1 class="content-title">Reportes de Bugs</h1>

            <ul class="mail-list">
                <?php
                $sql1 = mysqli_query($connection, "SELECT * FROM errores ORDER BY ID DESC");

                if (mysqli_num_rows($sql1) == 0) {
                    echo '<li>No tienes ningun bug para solventar</li>';
                } else {
                    $no = 1;
                    while ($row = mysqli_fetch_assoc($sql1)) {
                        ?>
                        <li id="bug<?php echo $row['ID']; ?>" class="">
                            <a id="<?php echo $row['ID']; ?>" onclick="recibidos(this.id)" aria-hidden="true">
                                <table border="0" style="width: 100%;">
                                    <tr id="estado<?php echo $row['ID']; ?>">
                                        <?php if ($row['estado'] === BNO) { ?>
                                            <td class="estiloasu" colspan = "2" id="bas<?php echo $row['ID']; ?>"><?php echo $row['Titulo']; ?></td>
                                        <?php } else { ?>
                                            <td  colspan = "2" id="bas<?php echo $row['ID']; ?>"><?php echo $row['Titulo']; ?></td>
                                        <?php } ?>


                                    </tr>
                                    <tr>
                                        <td id="bde<?php echo $row['ID']; ?>"><?php echo $row['Usuario']; ?></td>
                                        <td style="text-align: right;" id="bfe<?php echo $row['ID']; ?>"><?php echo $row['fecha']; ?></td>
                                        <td id="bme<?php echo $row['ID']; ?>" class="hidden"><?php echo $row['Mensaje']; ?></td>
                                    </tr>
                                </table>
                            </a>
                        </li>
                        <?php
                        $no++;
                    }
                }
                ?>
            </ul>
        </div>
    </div>
</div>


<div id = "BugDetail" class = "modal fade" role = "dialog" style="height: 500px;">
    <div class = "modal-dialog">
        <div class = "modal-content" id="visualiza">
            <div class="modal-header">
                <table border="0" style="width: 100%;">

                    <tr>
                        <td id="bid" class="hidden"></td>
                        <td id="basu" style="vertical-align:bottom">PRUEBAS</td>
                        <td style="vertical-align: bottom; text-align: right" id="bfech">NUNCA</td>
                    </tr>

                </table>
            </div>
            <div class = "modal-body" style="height: 200px;">
                <table border="0" style="width: 100%;">
                    <tr>
                        <td style="padding-top: 0px;">
                            <textarea style="width:100%; height: 180px; overflow:auto; resize:none; border: none;" id="bmens" readonly=""></textarea>
                        </td>
                    </tr>               
                </table>                
            </div>
            <div class="modal-footer">
                <table border="0" style="width: 100%;">
                    <form method="POST" id="delbugreport">
                        <tr>
                            <td style="width: 50%;">

                                <input type="hidden" id="idbug" name="idbug">
                                <button class="btn btn-warning btn-md" type="submit" style="width: 100%; padding: 10px;">Borrar</span></button>

                            </td>

                            <td style="width: 50%;"><button class="btn btn-danger btn-md" data-dismiss="modal" role="button" style="width: 100%; padding: 10px;">Cancelar</button></td>
                        </tr>  
                    </form>
                </table>  
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function recibidos(recibidosid) {

        var rer = document.getElementById('bde' + recibidosid).innerHTML;
        var asr = document.getElementById('bas' + recibidosid).innerHTML;
        var mer = document.getElementById('bme' + recibidosid).innerHTML;
        var fecr = document.getElementById('bfe' + recibidosid).innerHTML;

        $('#BugDetail').modal({show: true});

        $('#basu').html('<b>' + asr + '</b>');
        $('#bfech').html(fecr);
        $('#bfor').html(rer);
        $('#bmens').html(mer);
        $('#idbug').val(recibidosid);

    }

    $('#delbugreport').submit(function () {
        $.ajax({
            type: 'POST',
            url: 'AJAX/funciones/bugs/delbugreport.php',
            data: $(this).serialize(),
            success: function (data) {
                $('#BugDetail').modal('toggle');
                $('#bug'+data).addClass('hidden');
                bootstrap_alert.warning('Reporte eliminado correctamente', 'info', 1500);
            }
        });

        return false;
    }); //Borra el mensaje recibido que tengos cargado en el modal de recibidos
</script>