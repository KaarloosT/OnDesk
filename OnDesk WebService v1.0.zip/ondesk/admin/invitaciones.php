<div class = "table-responsive" style="width: 100%;">
    <table class = "table" border="0">
        <tr>
            <th class=""><center>Codigo Invitacion</center></th><!--Nombre del archivo -->
        <th class="hidden-xs"><center>Tipo Invitacion</center></th><!--Tamaño del fichero -->
        <th class="hidden-xs"><center>Usos Restantes</center></th><!--Extension del fichero -->
        <th class=""><center>Acciones</center></th><!--Acciones sobre el fichero-->
        </tr>
        <thead>
        <tbody>
            <?php
            $sql = mysqli_query($connection, "SELECT * FROM invitaciones");

            if (mysqli_num_rows($sql) == 0) {
                echo '<tr><td colspan="8">No existen invitaciones, prueba a crear una <a data-toggle="modal" data-target="#generainvitaciones">aqui</a>.</td></tr>';
            } else {
                $no = 1;
                while ($row = mysqli_fetch_assoc($sql)) {
                    ?>

            <tr id="inv<?php echo $row['ID']; ?>">
                        <td class=""><center id="nombreusuario<?php echo $row['ID'] ?>"><?php echo $row['code']; ?></center></td>
                <td class="hidden-xs"><center id="username<?php echo $row['ID'] ?>"><?php echo $row['type']; ?></center></td>
                <td class="hidden-xs"><center id="correousuario<?php echo $row['ID'] ?>"><?php echo $row['usos']; ?></center></td>
                <td>
                <center>
                    
                    <!--<a id="<?php echo $row['ID']; ?>" onclick="copiainv(this.id)" title="Copiar Invitacion" class="btn btn-primary btn-md"><span class="fa fa-copy" aria-hidden="true"></span></a>-->
                    <a title="Copiar Invitacion" class="btn btn-primary btn-md" data-clipboard-text="<?php echo $row['code']; ?>"><span class="fa fa-copy" aria-hidden="true"></span></a>
                    

                    <a id="<?php echo $row['ID']; ?>" onclick="eliminainv(this.id)"  title="Borrar Invitacion" class="btn btn-danger btn-md"><span class="fa fa-trash" aria-hidden="true"></span></a>
                </center>
                </td>
                </tr>


                <?php
                $no++;
            }
        }
        ?>   
        </tbody>
    </table>
</div>

<script type="text/javascript">

    var clipboard = new Clipboard('.btn');

    clipboard.on('success', function (e) {

        bootstrap_alert.warning('Enlace Copiado al portapapeles', 'info', 1500);


    });


    function copiainv(invid) {

        alert(invid);
        bootstrap_alert.warning('Invitacion copiada al portapapeles', 'info', 1500);

    }

    function eliminainv(invid) {

        alert(invid);
        $.ajax({
            type: 'POST',
            url: 'AJAX/funciones/invitaciones/deleteinv.php',
            data: "idinv=" + invid,
            success: function (del) {
                $('#inv' + invid).addClass('hidden');
                console.log(del);
                bootstrap_alert.warning(del, 'info', 1500);
            }
        });

    }


</script>








