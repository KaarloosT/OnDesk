<?php

session_start();
require '../connect.php';

$nombreusuario = $_SESSION['usuario'];

$consulta = "SELECT * FROM user where usuario='$nombreusuario'";

$resultadousuario = mysqli_query($connection, $consulta) or die(mysqli_error($connection));

while ($row = mysqli_fetch_array($resultadousuario)) {
    $idu = $row["ID"];
}


$ruta = "filesuploaded/" . $nombreusuario . "/imgprofile/";
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$nombrefinal = $nombre . " " . $apellidos;
$fichero = $_FILES["userimage"]["name"];
$nombreficherotmp = $_FILES["userimage"]["tmp_name"];
$rutafinal = $ruta . $fichero;


if ($nombre == "" && $fichero != null) {
    //Sin nombre pero con foto
    $userupdate = "UPDATE user SET profileimg='$rutafinal' WHERE ID=$idu";
    mysqli_query($connection, $userupdate) or die(mysqli_error($connection));
    move_uploaded_file($nombreficherotmp, $rutafinal);
    header('Location: archivos-bs.php');
    
} else if ($nombre != "" && $fichero == null) {
    //Con nombre pero sin foto
    $userupdate = "UPDATE user SET name='$nombrefinal' WHERE ID=$idu";
    mysqli_query($connection, $userupdate) or die(mysqli_error($connection));
    header('Location: archivos-bs.php');
} else if ($nombre == "" && $fichero == null) {
    //Sin nombre ni foto
    header('Location: archivos-bs.php');
} else {
    //Con nombre y foto
    $userupdate = "UPDATE user SET name='$nombrefinal', profileimg='$rutafinal' WHERE ID=$idu";
    mysqli_query($connection, $userupdate) or die(mysqli_error($connection));
    move_uploaded_file($nombreficherotmp, $rutafinal);
    header('Location: archivos-bs.php');
}
?>
