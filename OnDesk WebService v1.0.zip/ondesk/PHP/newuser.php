<?php

session_start();

require 'connect.php';

if ($registros === 'C') {

    $estadoregistros = 'Actualmente, los registros se encuentran deshabilitados';
    $estadoinputs = 'disabled';
}

if ($registros === 'I') {

    $estadoregistros = 'Actualmente, solo aceptamos registros mediante invitacion';
    $textomodal = 'Actualmente, por diversos motivos, solo aceptamos nuevos registros mediante el uso de una invitacion';
    $estadoinputs = 'disabled';
    $estado = 'I';
}


if (isset($_POST['username'])) {

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = sha1($_POST['password']);
    $date = date("d/m/Y");
    //$img = 'profileimg/Fire_Meme2.JPG';
    $img = 'resources/iconusers/' . rand(1, 4) . '.png';


    if ($registros === 'I') {

        $code = $_POST['invcod'];

        $queryinv = "SELECT * FROM invitaciones WHERE code='$code'";

        $result = mysqli_query($connection, $queryinv) or die(mysqli_error($connection));

        while ($row = mysqli_fetch_array($result)) {

            $idinv = $row['ID'];
            $usos = $row['usos'];
        }

        $nuevousos = $usos - 1;

        $actualizausos = "UPDATE invitaciones set usos='$nuevousos' WHERE ID='$idinv';";
        $queryusos = mysqli_query($connection, $actualizausos) or die(mysqli_error($connection));

        $query = "INSERT INTO user (usuario, email, password, fecharegistro, profileimg) VALUES ('$username', '$email', '$password', '$date', '$img')";
        mysqli_query($connection, $query);

        mkdir('filesuploaded/' . $username . '/imgprofile', 0777, true);

        $_SESSION['usuario'] = $username;
    } else if ($registros === 'A') {

        $query = "INSERT INTO user (usuario, email, password, fecharegistro, profileimg) VALUES ('$username', '$email', '$password', '$date', '$img')";
        mysqli_query($connection, $query);
        mkdir('filesuploaded/' . $username . '/imgprofile', 0777, true);
        $_SESSION['usuario'] = $username;
    } else if ($registros === 'C') {

        header('Location: index.php');
    }

    //$query = "INSERT INTO user (usuario, email, password, fecharegistro, profileimg) VALUES ('$username', '$email', '$password', '$date', '$img')";
}

if (isset($_SESSION['usuario'])) {

    header('Location: userdata.php');
}
?>
