<?php require 'header.php'; ?>     
<?php 

//Si el usuario ya tiene un nombre (no confundir con nombre de usuario)  e intenta acceder a esta pagina, se le redirige a la pagina princpal
if($nombre != ""){
     echo '<script type="text/javascript">window.location = "index.php"</script>';
 }


?>


<style type="text/css">

    .stepwizard-step p {
        margin-top: 10px;
    }

    .stepwizard-row {
        display: table-row;
    }

    .stepwizard {
        display: table;
        width: 100%;
        position: relative;
    }

    .stepwizard-step button[disabled] {
        opacity: 1 !important;
        filter: alpha(opacity=100) !important;
    }

    .stepwizard-row:before {
        top: 14px;
        bottom: 0;
        position: absolute;
        content: " ";
        width: 100%;
        height: 1px;
        background-color: #ccc;
        z-order: 0;

    }

    .stepwizard-step {
        display: table-cell;
        text-align: center;
        position: relative;
    }

    .btn-circle {
        width: 30px;
        height: 30px;
        text-align: center;
        padding: 6px 0;
        font-size: 12px;
        line-height: 1.428571429;
        border-radius: 15px;
    }



</style>

<div class="container">
    <br>
    <div class="stepwizard">
        <div class="stepwizard-row setup-panel">
            <div class="stepwizard-step">
                <a type="button" class="btn btn-primary btn-circle" disabled="disabled" id="button1">1</a>
            </div>
            <div class="stepwizard-step">
                <a type="button" class="btn btn-default btn-circle" disabled="disabled" id="button2">2</a>
            </div>
        </div>
    </div>
    <form method="POST" id="userdata" action="PHP/setcustomdata.php" enctype="multipart/form-data">
        <div class="row setup-content" id="step-1">
            <div class="col-xs-12">
                <div class="col-md-12">
                    <h3> Datos adicionales</h3>
                    <div class="form-group">
                        <label class="control-label">Nombre</label>
                        <input maxlength="100" type="text" name="nombre" class="form-control" placeholder="Introduce tu nombre" id="camponombre">
                    </div>
                    <div class="form-group">
                        <label class="control-label">Apellidos</label>
                        <input maxlength="100" type="text" name="apellidos" class="form-control" placeholder="Introduce tus apellidos" id="campoapellidos">
                    </div>
                    <a href="archivos-bs.php" class="btn btn-danger btn-lg pull-left" type="button">Omitir</a>
                    <button id="nextbutton" class="btn btn-primary nextBtn btn-lg pull-right" type="button">Siguiente</button>
                </div>
            </div>
        </div>
        <div class="row setup-content hidden" id="step-2">
            <div class="col-xs-12">
                <div class="col-md-12">
                    <h3> Imagen Perfil</h3>
                    <div class="form-group">
                        <span>Te hemos asignado una imagen automaticamente, puedes cambiarla en el formulario de abajo</span>
                        <br><br>
                        <center><img src="<?php echo $imgprofile ?>" height="240px" width="240px" id="usuimg"></center>
                    </div>


                    <center>

                        <button class="btn btn-info btn-file btn-md" style="width: 240px;" type="button" >Selecionar Archivo<input accept="image/*" type="file" id="userimage" name="userimage"></button>

                    </center>
                    <button class="btn btn-success btn-lg pull-right" type="submit">Finish!</button>
                    <button id="backbutton" class="btn btn-primary nextBtn btn-lg pull-left" type="button">Atras</button>
                </div>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">

    $('#button1').click(function () {

        $('#button2').removeClass('btn-primary');
        $('#button1').removeClass('btn-default');
        $('#button2').addClass('btn-default');
        $('#button1').addClass('btn-primary');
        $('#step-1').removeClass('hidden');
        $('#step-2').addClass('hidden');

    });

    $('#button2').click(function () {

        $('#button1').removeClass('btn-primary');
        $('#button2').removeClass('btn-default');
        $('#button1').addClass('btn-default');
        $('#button2').addClass('btn-primary');
        $('#step-2').removeClass('hidden');
        $('#step-1').addClass('hidden');

    });

    $('#nextbutton').click(function () {

        $('#button2').trigger('click');

    });

    $('#backbutton').click(function () {

        $('#button1').trigger('click');

    });

    $("#userimage").change(function () {
        $("[for=file]").html(this.files[0].name);
        $("#usuimg").attr("src", URL.createObjectURL(this.files[0]));
        var ruta = $("#userimage").val();
        var filename = ruta.replace(/^.*\\/, "");
        $('#nombreimagen').val(filename);
    });





</script>

