<?php

session_start();
require('connect.php');

function generarCodigo($longitud) {
    $key = '';
    $pattern = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!_';
    $max = strlen($pattern) - 1;
    for ($i = 0; $i < $longitud; $i++) {
        $key .= $pattern{mt_rand(0, $max)};
    }
    return $key;
}


    $nombreusuario = $_SESSION['usuario'];

    $ruta = "filesuploaded/" . $nombreusuario . "/";

    //--------------------------------------------------------------
    //                    VARIABLES QUE USAREMOS                   |
    //--------------------------------------------------------------

    $fichero = $_FILES['file1']['name'];

    $filesize = $_FILES['file1']['size'];

    $filetype = end((explode(".", $fichero)));

    $nombreficherotmp = $_FILES["file1"]["tmp_name"];

    $visibilidad = $_POST['pruebasfichero'];

    $rutafichero = $ruta . $fichero;

    $descripcion = "";

    $url = generarCodigo(20);
    
    $date = date("d/m/Y");

    //--------------------------------------------------------------

    if (!file_exists($rutafichero)) {

        $result = move_uploaded_file($nombreficherotmp, $rutafichero);


        if ($result) {

            $query = "INSERT INTO uploads (descripcion, filename, filetype, filesize, owner, hidden, route, url, fechasubida) VALUES ('$descripcion', '$fichero', '$filetype', '$filesize', '$nombreusuario', '$visibilidad', '$rutafichero', '$url', '$date')";

            mysqli_query($connection, $query);

            echo "<b>$fichero</b> subido correctamente";
        
            
        } else {

            echo "Ha ocurrido un error en la subida del archivo al servidor";
        }
    }
?>