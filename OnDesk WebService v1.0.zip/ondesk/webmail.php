<?php require_once 'header.php'; ?> 

<style type="text/css">

    body {
        background-color:#F7F7F7;
        font-family: 'Open Sans', sans-serif;
    }
    /*Navbar*/
    .navbar-default {
        background-color:#fff;
        border-bottom-color:#E3E3E3;
    }
    .navbar-default .navbar-nav>.active>a, 
    .navbar-default .navbar-nav>.active>a:hover, 
    .navbar-default .navbar-nav>.active>a:focus{
        background-color:transparent!important;
    }
    .navbar-default .btn-compose {
        padding-right:10px;
        border-right:1px solid #F0F0F0;
    }
    /*Forms setup*/

    .float-label{
        font-size:10px;
    }

    /*Content Container*/
    .content-container {
        background-color:#fff;
        padding:35px 20px;
        margin-bottom:20px;
    }
    h1.content-title{
        font-size:32px;
        font-weight:300;
        text-align:center;
        margin-top:0;
        margin-bottom:20px;
        font-family: 'Open Sans', sans-serif!important;
    }
    /*Compose*/
    .btn-send{
        text-align:center;
        margin-top:20px;
    }
    /*mail list*/

    ul.mail-list{
        padding:0;
        margin:0;
        list-style:none;
        margin-top:30px;
    }
    ul.mail-list li a{
        display:block;
        border-bottom:1px solid #CFCFCF;
        padding:20px;
        text-decoration:none;
    }

    ul.mail-list li a:hover{
        background-color:#DBF9FF;
    }
    ul.mail-list li span{
        display:block;
    }
    ul.mail-list li span.mail-sender{
        font-weight:600;
        color:#8F8F8F;
    }
    ul.mail-list li span.mail-subject{
        color:#8C8C8C;
    }
    ul.mail-list li span.mail-message-preview{
        display:block;
        color:#A8A8A8;
    }

    .estiloasu{

        font-weight: bold;

    }

</style><!--Estilos CSS del sistema de mensajeria -->


<div class = "table-responsive" style="width: 100%;">
    <table class = "table" style="background-color: lightblue;">
        <tr>
            <th><center><a type="button" class="btn btn-success navbar-btn" href="#compose" role="tab" data-toggle="tab"> <span class="glyphicon glyphicon-pencil"></span> &nbsp;Nuevo</a></center></th><!--Nombre del archivo -->
        <th ><center><a type="button" class="btn btn-default navbar-btn" id="bandeja" href="#inbox" role="tab" data-toggle="tab">Recibidos <span class="label label-success"><?php echo mysqli_num_rows($numeromensajes); ?></span></a></center></th><!--Tamaño del fichero -->
            <!--<th ><center><a type="button" class="btn btn-default navbar-btn" href="#sent-mail" role="tab" data-toggle="tab">Enviados</a></center></th>Extension del fichero -->
        </tr>
    </table>
</div> <!--Botones para navegar en el sistema de mensajeria-->

<div class="tab-content"> 

    <!--BANDEJA DE ENTRADA-->
    <div class="tab-pane active" id="inbox">
        <!--<div class="container">-->
        <div class="content-container clearfix">
            <div class="col-md-12">
                <h1 class="content-title">Bandeja de Entrada</h1>

                <ul class="mail-list">
                    <?php
                    $sql1 = mysqli_query($connection, "SELECT * FROM mensajes WHERE para='$username' and NOT estado='BORRADR' ORDER BY ID DESC");

                    if (mysqli_num_rows($sql1) == 0) {
                        echo '<li>No tienes ningun mensaje nuevo</li>';
                    } else {
                        $no = 1;
                        while ($row = mysqli_fetch_assoc($sql1)) {
                            ?>
                            <li id="lista<?php echo $row['ID']; ?>" class="">
                                <a id="<?php echo $row['ID']; ?>" onclick="recibidos(this.id)" title="Haz Click para ver el mensaje" aria-hidden="true">
                                    <table border="0" style="width: 100%;">
                                        <tr id="linea<?php echo $row['ID']; ?>">
                                            <?php if ($row['estado'] === NOREAD) { ?>
                                                <td class="estiloasu" colspan = "2" id="ras<?php echo $row['ID']; ?>"><?php echo $row['asunto']; ?></td>
                                            <?php } else { ?>
                                                <td  colspan = "2" id="ras<?php echo $row['ID']; ?>"><?php echo $row['asunto']; ?></td>
                                            <?php } ?>


                                        </tr>
                                        <tr>
                                            <td id="rde<?php echo $row['ID']; ?>"><?php echo $row['de']; ?></td>
                                            <td style="text-align: right;" id="rfe<?php echo $row['ID']; ?>"><?php echo $row['fechaenvio']; ?></td>
                                            <td id="rme<?php echo $row['ID']; ?>" class="hidden"><?php echo $row['mensaje']; ?></td>
                                        </tr>
                                    </table>
                                </a>
                            </li>
                            <?php
                            $no++;
                        }
                    }
                    ?>
                </ul>
            </div>
        </div>
        <!--</div>-->
    </div>
    <!--BANDEJA DE ENTRADA-->

    <!--ESCRIBIR MENSAJE NUEVO-->
    <div class="tab-pane" id="compose">
        <div class="container">
            <div class="content-container clearfix">
                <h1 class="content-title">Nuevo Mensaje</h1>
                <div class="col-md-12">
                    <form method="POST" id="messagesend">
                        <div class="form-group">
                            <input type="text" class="hidden" value="<?php echo $username ?>" name="nusuario">
                            <!--Input con una lista asignada donde se muestran todos los usuarios disponibles del sistema-->
                            <input list="userlist" id="para" name="para" type="text" class="form-control" placeholder="Destinatario">
                            <datalist id="userlist">
                                <?php
                                $sqlusuario = mysqli_query($connection, "SELECT * FROM user");
                                $no = 1;
                                while ($row = mysqli_fetch_assoc($sqlusuario)) {
                                    ?>
                                    <option value="<?php echo $row['usuario']; ?>">
                                        <?php
                                        $no++;
                                    }
                                    ?>
                            </datalist>
                        </div>
                        <div class="form-group">
                            <input type="text" id="uasu" name="asunto" class="form-control" placeholder="Asunto">
                        </div>
                        <textarea class="form-control" id="umsg" name="mensaje" placeholder="Mensaje" style="overflow:auto;resize:none;height:200px;"></textarea>
                        <div class="btn-send">
                            <button class="btn btn-success btn-lg disabled" id="enviarmsg" name="enviar" type="button"><span class="glyphicon glyphicon-send"></span> Enviar</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--ESCRIBIR MENSAJE NUEVO-->



</div>



<!--MENSAJES RECIBIDOS-->
<div id = "RecMsg" class = "modal fade" role = "dialog" style="height: 500px;">
    <div class = "modal-dialog">
        <div class = "modal-content" id="visualiza">
            <div class="modal-header">
                <table border="0" style="width: 100%;">
                    <tr>
                        <td id="rid" class="hidden"></td>
                        <td id="rasu" style="vertical-align:bottom">PRUEBAS</td>
                        <!--<td style="text-align: right;"><a title="Responde a este mensaje" class="btn btn-default btn-md" style="padding: 5px;" onclick="reply()">Responder <span class="fa fa-mail-reply" ></span></a><BR><BR></td>-->
                    </tr>
                    <tr>
                        <td id="rfor">para: MI</td>
                        <td style="text-align: right;" id="rfech">NUNCA</td>
                    </tr>
                </table>
            </div>
            <div class = "modal-body" style="height: 200px;">
                <table border="0" style="width: 100%;">
                    <tr>
                        <td style="padding-top: 0px;">
                            <textarea style="width:100%; height: 180px; overflow:auto; resize:none; border: none;" id="rmens" readonly=""></textarea>
                        </td>
                    </tr>               
                </table>                
            </div>
            <div class="modal-footer">
                <table border="0" style="width: 100%;">
                    <form method="POST" action="deletemsg.php" id="delmsgreci" name="delmsgreci">
                        <tr>
                            <td style="width: 50%;">

                                <input type="hidden" id="idmensajerecibido" name="idmensajerecibido">
                                <button class="btn btn-warning btn-md" type="submit" style="width: 100%; padding: 10px;">Borrar</span></button>

                            </td>

                            <td style="width: 50%;"><button class="btn btn-danger btn-md" data-dismiss="modal" role="button" style="width: 100%; padding: 10px;">Cancelar</button></td>
                        </tr>  
                    </form>
                </table>  
            </div>
        </div>
    </div>
</div> <!--FUNCIONA EL BORRADO POR AJAX-->
<!--MENSAJES RECIBIDOS-->

<!--RESPONDE MENSAJE-->
<div id = "RespMsg" class="modal fade" role = "dialog" style="height: 500px;">
    <div class = "modal-dialog">
        <div class = "modal-content" id="visualiza">
            <div class="modal-header">
                <table border="0" style="width: 100%;">
                    <tr>
                        <td id="resasun" style="vertical-align:bottom">PRUEBAS</td>
                    </tr>
                    <tr>
                        <td id="resfor">para: MI</td>
                    </tr>
                </table>
            </div>
            <div class = "modal-body" style="height: 200px;">
                <table border="0" style="width: 100%;">
                    <tr>
                        <td style="padding-top: 0px;">
                            <input type="hidden" id="respid" name="idmensaje">
                            <input type="hidden" id="resrem" name="remitentemensaje">
                            <input type="hidden" id="resusr" name="usuariomensaje">
                            <textarea style="width:100%; height: 180px; overflow:auto; resize:none; border: none;" id="rmens" readonly=""></textarea>
                        </td>
                    </tr>               
                </table>                
            </div>
            <div class="modal-footer">
                <table border="0" style="width: 100%;">
                    <tr>
                        <td style="width: 50%;"><button class="btn btn-warning btn-md" style="width: 100%; padding: 10px;">Enviar</span></button></td>
                        <td style="width: 50%;"><button class="btn btn-danger btn-md" data-dismiss="modal" role="button" style="width: 100%; padding: 10px;">Cancelar</button></td>
                    </tr>                    
                </table>  
            </div>
        </div>
    </div>
</div> <!--FALTA POR IMPLEMENTAR-->
<!--RESPONDE MENSAJE-->


<script>

    function recibidos(recibidosid) {

        var rer = document.getElementById('rde' + recibidosid).innerHTML;
        var asr = document.getElementById('ras' + recibidosid).innerHTML;
        var mer = document.getElementById('rme' + recibidosid).innerHTML;
        var fecr = document.getElementById('rfe' + recibidosid).innerHTML;

        $.ajax({
            url: 'AJAX/funciones/mail/mailstatus.php',
            data: "mailid=" + recibidosid,
            type: 'post',
            success: function (test) {
                $('#RecMsg').modal({show: true});
                document.getElementById('rasu').innerHTML = '<b>' + asr + '</b>';
                document.getElementById('rfech').innerHTML = fecr;
                document.getElementById('rfor').innerHTML = rer;
                document.getElementById('rmens').innerHTML = mer;
                document.getElementById('idmensajerecibido').value = recibidosid;
                $('#ras' + recibidosid).removeClass('estiloasu');
            }
        });



    } //Carga el modal de mensajes recibidos y rellena los campos con los datos

    $('#delmsgreci').submit(function () {
        idli = document.getElementById('idmensajerecibido').value;
        idbo = 'lista' + idli;
        $.ajax({
            type: 'POST',
            url: 'AJAX/funciones/mail/deletemsg.php',
            data: $(this).serialize(),
            success: function (data) {
                $('#RecMsg').modal('toggle');
                document.getElementById(idbo).className += 'hidden';
                bootstrap_alert.warning('Mensaje eliminado correctamente', 'warning', 2500);
            }
        });

        return false;
    }); //Borra el mensaje recibido que tengos cargado en el modal de recibidos

    $('#messagesend').submit(function () {
        $.ajax({
            type: 'POST',
            url: 'AJAX/funciones/mail/sendmsg.php',
            data: $(this).serialize(),
            success: function (data1) {
                $('#uto').val("");
                $('#uasu').val("");
                $('#umsg').val("");
                $("#bandeja").trigger("click");
                bootstrap_alert.warning('Mensaje Enviado', 'warning', 2500);
            }
        });

        return false;
    }); //Envia un nuevo mensajes con los datos que introduce el usuario

    $('#para').focusout(function () {
        $.ajax({
            type: 'POST',
            url: 'AJAX/funciones/mail/userexist.php',
            data: 'checkuser=' + $('#para').val(),
            success: function (data) {
                console.log(data);
                if (data === 'si') {

                    $('#enviarmsg').attr('type', 'submit');
                    $('#enviarmsg').removeClass('disabled');

                } else {

                    $('#enviarmsg').attr('type', 'button');
                    $('#enviarmsg').addClass('disabled');
                    bootstrap_alert.warning('El usuario introducido no existe', 'warning', 2500);


                }
            }
        });
    });


</script>