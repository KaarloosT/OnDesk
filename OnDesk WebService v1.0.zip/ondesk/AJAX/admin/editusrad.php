<?php

require '../../connect.php';

$usrid = $_POST['idusr'];
$nuevonombre = $_POST['usrnm'];
$nuevomail = $_POST['usermail'];
$tipocuenta = $_POST['accountype'];
$estadocuenta = $_POST['accountest'];

//echo $usrid.' y '.$nuevonombre.' y '.$nuevomail.' y '.$tipocuenta.' y '.$estadocuenta;

$updateuser = "UPDATE user SET name='$nuevonombre', email='$nuevomail', admin='$tipocuenta', activo='$estadocuenta'  WHERE ID=$usrid";

//echo $updateuser;
$result = mysqli_query($connection, $updateuser) or die(mysqli_error($connection));
if ($result){
    
    echo $usrid;
    
}