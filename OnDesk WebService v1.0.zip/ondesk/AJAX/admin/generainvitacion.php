<?php

require 'connect.php';

$tipoinv = $_POST['tipoinvitacion'];
$numerousos = $_POST['numeroinv'];
$custominv = $_POST['custominv'];
$fecha = date("d/m/Y");



if ($tipoinv === 'R') {

    function generarInvitacion($longitud) {
        $key = '';
        $pattern = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!_';
        $max = strlen($pattern) - 1;
        for ($i = 0; $i < $longitud; $i++) {
            $key .= $pattern{mt_rand(0, $max)};
        }
        return $key;
    }

    $invitacion = generarInvitacion(30);
    $queryinv = "INSERT INTO invitaciones (code, type, usos) VALUES ('$invitacion', '$tipoinv', '$numerousos')";

    $genera = mysqli_query($connection, $queryinv);
    if ($genera) {
        echo 'Invitacion aleatoria generada con ' . $numerousos . ' usos con exito';
    } else {

        echo 'Algo ha fallado';
    }
} else if ($tipoinv === 'C') {

    $queryinv = "INSERT INTO invitaciones (code, type, usos) VALUES ('$custominv', '$tipoinv', '$numerousos')";

    $genera = mysqli_query($connection, $queryinv);

    if ($genera) {
        echo 'Invitacion personalizada generada con ' . $numerousos . ' usos con exito';
    }
}
