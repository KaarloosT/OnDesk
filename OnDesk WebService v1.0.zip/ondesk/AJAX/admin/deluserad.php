<?php

require '../../connect.php';

$iduser = $_POST['borrausuario'];


$queryborrado = "DELETE FROM user WHERE ID=$iduser";

$result = mysqli_query($connection, $queryborrado) or die(mysqli_error($connection));

if ($result){
    
    echo 'Usuario Borrado Correctamente';
    
}else{
    
    echo 'Ha ocurrido un error';
    
}
