<?php

require '../../connect.php';

$registro = $_POST['estadoregistro'];
$login = $_POST['estadologin'];

if ($registro === 'A') {

    $estador = 'Abiertos';
} else if ($registro === 'C') {

    $estador = 'Cerrados';
} else if ($registro === 'I') {

    $estador = 'por Invitacion';
}

if ($login === 'A') {

    $estadol = 'Abiertos';
} else if ($login === 'C') {

    $estadol = 'Cerrados';
}

$update = "UPDATE config SET Register='$registro', Login='$login'";


$result = mysqli_query($connection, $update) or die(mysqli_error($connection));

if ($result) {

    echo 'Registros <b>' . $estador . '</b> y Logins <b>' . $estadol.'</b>';
} else {

    echo 'Error';
}
