<?php

require '../../connect.php';

$de = $_POST['remitente'];
$desti = $_POST['destinatario'];
$nasunto = $_POST['asunto'];
$nmensaje = $_POST['mensaje'];
$fecha = date("d/m/Y");
$estado = "NOREAD";

//Insertamos los datos que hemos asignado a variables en la base de datos
$query = "INSERT INTO mensajes (de, para, asunto, mensaje, estado, fechaenvio) VALUES ('$de', '$desti', '$nasunto', '$nmensaje', '$estado', '$fecha')";
//Hacemos una query pasando como parametros los datos de conexion y la funcion insert que hemos asignado a una variable
$result = mysqli_query($connection, $query);
