<?php
require '../../../connect.php';

$idbug = $_POST['idbug'];

$borrabug = "DELETE FROM errores WHERE ID=$idbug";

$lanzaborrado = mysqli_query($connection, $borrabug);

if($lanzaborrado){echo $idbug;}
    
    



