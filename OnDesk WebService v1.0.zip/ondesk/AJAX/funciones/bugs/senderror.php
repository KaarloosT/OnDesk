<?php
require ('../../../connect.php');


$usuario = $_POST['usuarioer'];
$titulo = $_POST['titulo'];
$mensaje = $_POST['mensaje'];
$fecha = date('d/m/Y');

$query = "INSERT INTO errores (Usuario, Titulo, Mensaje, estado, fecha) VALUES ('$usuario', '$titulo', '$mensaje', 'BNO', '$fecha')";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));


echo "Tus datos fueron enviados correctamente <b>" . $usuario . "</b>";
?>