<?php

require '../../connect.php';

//$user = 'KaarloosT';
$code = $_POST['codeinv'];
$updateuser = "SELECT * FROM invitaciones WHERE code='$code'";

//echo $updateuser;
$result = mysqli_query($connection, $updateuser) or die(mysqli_error($connection));

while ($row = mysqli_fetch_array($result)) {

    $invitacion = $row['code'];
    $usos = $row['usos'];
}

    if ($usos > 0) {

        echo 'valido';
        
    } else {

        echo 'novalido';
        
    }