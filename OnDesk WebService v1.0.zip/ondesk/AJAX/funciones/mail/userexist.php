<?php

require '../../../connect.php';


//$user = 'KaarloosT';
$username = $_POST['checkuser'];
$updateuser = "SELECT * FROM user WHERE usuario='$username'";

//echo $updateuser;
$result = mysqli_query($connection, $updateuser) or die(mysqli_error($connection));

while ($row = mysqli_fetch_array($result)) {

    $usuario = $row['usuario'];
}

if ($username === $usuario) {

    echo 'si';
    
} else {

    echo 'no';
}