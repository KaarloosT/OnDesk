<?php
require '../../../connect.php';

$mensajeid = $_POST['mailid'];

$updatestatus = "UPDATE mensajes SET estado='READ' WHERE ID='$mensajeid'";
$result = mysqli_query($connection, $updatestatus);

if ($result){
    
    echo 'OK';
    
}else{
    
    echo 'NO OK';
    
}
?>