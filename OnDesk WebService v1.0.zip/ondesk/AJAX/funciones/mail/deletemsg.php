<?php

require '../../../connect.php';



$idmsg = $_POST['idmensajerecibido'];

$query = "DELETE FROM mensajes WHERE ID='$idmsg'";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));





?>

