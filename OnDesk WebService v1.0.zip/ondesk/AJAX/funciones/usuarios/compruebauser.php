<?php

require '../../connect.php';

//$user = 'KaarloosT';
$user = $_POST['checkuser'];
$updateuser = "SELECT * FROM user WHERE usuario='$user'";

//echo $updateuser;
$result = mysqli_query($connection, $updateuser) or die(mysqli_error($connection));

while ($row = mysqli_fetch_array($result)) {

    $usuario = $row['usuario'];
}

if ($user === $usuario) {

    echo 'Ocupado';
} else {

    echo 'Disponible';
}