<?php

require '../../connect.php';

//$user = 'KaarloosT';
$mail = $_POST['checkmail'];
$updateuser = "SELECT * FROM user WHERE email='$mail'";

//echo $updateuser;
$result = mysqli_query($connection, $updateuser) or die(mysqli_error($connection));

while ($row = mysqli_fetch_array($result)) {

    $email = $row['email'];
}

if ($mail === $email) {

    echo 'Ocupado';
    
} else {

    echo 'Disponible';
}