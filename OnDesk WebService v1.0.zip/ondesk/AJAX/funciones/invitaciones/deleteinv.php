<?php

require '../../../connect.php';

$idinv = $_POST['idinv'];


$queryborrado = "DELETE FROM invitaciones  WHERE ID=$idinv";

$result = mysqli_query($connection, $queryborrado) or die(mysqli_error($connection));

if ($result){
    
    echo 'Invitacion Borrada Correctamente';
    
}else{
    
    echo 'Ha ocurrido un error';
    
}






?>