<?php

require '../../../connect.php';


$id = $_POST['filenum'];
$nombre = $_POST['filename'];
$privado = $_POST['privacy'];
$extension = $_POST['filext'];
$lastname = $_POST['lastname'];
$usuari = $_POST['nomuser'];

$nombref = explode(".", $nombre);

$nombrefinal = $nombref[0] . '.' . $extension;
$rutatabla = 'filesuploaded/' . $usuari . '/' . $nombrefinal;
$rutafinal = '../../../filesuploaded/' . $usuari . '/' . $nombrefinal;



rename('../../../filesuploaded/' . $usuari . '/' . $lastname, $rutafinal);



$updatefile = "UPDATE uploads SET filename='$nombrefinal', hidden='$privado', route='$rutatabla' WHERE ID='$id';";
$result = mysqli_query($connection, $updatefile);



if ($privado == 0) {

    echo "Publico";
} else {

    echo "Privado";
}
?>
