<?php
session_start();
require '../../../connect.php';

$ficheroid = $_POST['borrafichero'];
$compruebafile = "SELECT * FROM uploads WHERE ID=$ficheroid";

$ficherore = mysqli_query($connection, $compruebafile);

while ($row = mysqli_fetch_array($ficherore)) {
    $ruta = $row['route'];
}

$rutafinal = '../../../'.$ruta;

if (file_exists($rutafinal)) {
    if (unlink($rutafinal)) {

        $borraregistrofile = "DELETE FROM uploads WHERE ID=$ficheroid";

        $hasborrado = mysqli_query($connection, $borraregistrofile);

        echo $ficheroid;
    }
}else{
    echo $rutafinal;
}
?>
