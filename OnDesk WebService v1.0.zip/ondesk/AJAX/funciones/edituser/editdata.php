<?php
session_start();
require '../../../connect.php';

$nombreusuario = $_SESSION['usuario'];
$nuevonombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$nombrefinal = $nuevonombre." ".$apellidos;

$userupdate = "UPDATE user SET name='$nombrefinal' WHERE usuario='$nombreusuario'";
$cambiadatos = mysqli_query($connection, $userupdate) or die(mysqli_error($connection));

if ($cambiadatos){
    
    echo $nombrefinal;    
    
}

