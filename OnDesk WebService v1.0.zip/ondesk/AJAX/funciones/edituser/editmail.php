<?php

session_start();
require '../../../connect.php';

$nombreusuario = $_SESSION['usuario'];
$nmail = $_POST['nuevomail'];
$nmail2 = $_POST['repitenuevomail'];

if ($nmail == $nmail2) {
    $mailupdate = "UPDATE user SET email='$nmail' WHERE usuario='$nombreusuario'";
    $cambiamail = mysqli_query($connection, $mailupdate) or die(mysqli_error($connection));
    if ($cambiamail) {

        echo $nmail;
        
    }
} else {
    
}
?>
