<?php

session_start();
require '../../../connect.php';

$nombreusuario = $_SESSION['usuario'];

$ruta = "../../../filesuploaded/" . $nombreusuario . "/imgprofile/";
$rutabd = 'filesuploaded/" . $nombreusuario . "/imgprofile/'.$fichero;
$fichero = $_FILES["userimage"]["name"];
$nombreficherotmp = $_FILES["userimage"]["tmp_name"];
$rutafinal = $ruta . $fichero;
$rutabd = 'filesuploaded/'. $nombreusuario . '/imgprofile/'.$fichero;

$userupdate = "UPDATE user SET profileimg='$rutabd' WHERE usuario='$nombreusuario'";
mysqli_query($connection, $userupdate) or die(mysqli_error($connection));
move_uploaded_file($nombreficherotmp, $rutafinal);

echo $rutafinal;
