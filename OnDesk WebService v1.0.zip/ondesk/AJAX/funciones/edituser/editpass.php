<?php
session_start();
require '../../../connect.php';

$usuario = $_SESSION['usuario'];
$apass = sha1($_POST['antiguapass']);
$npass1 = sha1($_POST['nuevapass']);
$npass2 = sha1($_POST['repitenuevapass']);

$cantiguapass = "SELECT * FROM user where usuario='$usuario'";
$checkapass = mysqli_query($connection, $cantiguapass);

while ($row = mysqli_fetch_array($checkapass)) {

    $password = $row["password"];
    
}

if ($apass == $password) {

    if ($npass1 == $npass2) {

        $updatepass = "UPDATE user SET password='$npass1' WHERE usuario='$usuario'";
        $cambiapass = mysqli_query($connection, $updatepass);
        if ($cambiapass) {

            echo 'Contraseña Actualizada Correctamente';
        }
    } else {

        echo 'La nueva contraseña no coincide';
    }
} else {
    
    echo 'La contraseña actual no coincide';
    
}


