<?php
require 'connect.php';

$menid = $_POST['menid'];

$borramsg = "DELETE FROM comentarios WHERE ID=$menid";

$lanzaborrado = mysqli_query($connection, $borramsg);

if($lanzaborrado){echo $menid;}else{echo $menid;}
    
    



