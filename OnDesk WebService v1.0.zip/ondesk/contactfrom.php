<?php
require('connect.php');
//Capturamos los datos que el usuario ha introducido y los asignamos a variables
if (isset($_POST['nombre']) && isset($_POST['email'])) {
    $nombre = $_POST['nombre'];
    $correo = $_POST['email'];
    $mensaje = $_POST['mensaje'];
    $fecha = date("d/m/Y");

    //Insertamos los datos que hemos asignado a variables en la base de datos
    $query = "INSERT INTO comentarios (nombre, email, mensaje, fecha) VALUES ('$nombre', '$correo', '$mensaje', '$fecha')";
    //Hacemos una query pasando como parametros los datos de conexion y la funcion insert que hemos asignado a una variable
    $result = mysqli_query($connection, $query);
}
?>   
<?php require 'librerias.php' ?>

<div class="container">
    <form method="POST" id="enviamensaje">
        <center><img src="resources/images/logo.png" style="margin-top: 20vh;" class="img img-responsive"></center>
        <br>
        <div class="form-group">
            <input type="text" class="form-control input-lg" name="email" id="email"  placeholder="Introduce tu correo electronico"/>
            <span id="chivatomail" style="padding: 0px;"></span>
        </div>

        <div class="for-group">
            <textarea class="form-control input-lg" id="mensaje" name="mensaje" placeholder="Escribe lo que quieres contarnos" style="overflow:auto;resize:none;height:300px;" required=""></textarea>

        </div>
        <br>
        <button type="submit" id="reg" name="inicio" class="btn btn-success btn-md" style="width: 100%; padding: 10px;"><span class="fa fa-send"></span> Enviar</button>
    </form>
</div>


<script type="text/javascript">

    $('#email').focusout(function () {
        var emil = $('#email').val();
        if (emil === "") {
            $('#chivatomail').html('Introduzca un email');
            $('#reg').attr('type', 'button');
            $('#reg').addClass('disabled');
        } else {
            $('#email').filter(function () {
                var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                if (!emailReg.test(emil)) {
                    console.log('Formato Email No Valido');
                    $('#chivatomail').html('Introduzca un email valido');
                    $('#reg').attr('type', 'button');
                    $('#reg').addClass('disabled');
                } else {
                    $('#chivatomail').html('');
                    $('#reg').attr('type', 'submit');
                    $('#reg').removeClass('disabled');
                }
            });
        }
    });




</script>