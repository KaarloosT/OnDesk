<?php require 'header.php'; ?>
<?php
if ($account !== 'Admin') {

    echo '<script type="text/javascript">window.location = "index.php"</script>';
}
?>


<style type="text/css">

    #page-wrapper {
        position: absolute;
        top: 51px;
        left: 0;
        width: 100%;
        height: 90%;
    }



    #btn {
        position: fixed;
        z-index: 400;
        top: 60px;
        left: 15px;

        transition: left 250ms;
        background-color: lightblue;
        padding: 5px;
        padding-top: 8px;
        border-radius: 10px;


    }
    #btn div {
        width: 30px;
        height: 4px;
        margin-bottom: 5px;
        background-color: #000000;

    }

    #btn.active {
        left: 250px;
    }
    #btn.active div {
        background-color: #343838;
    }

    #box {
        position: fixed;
        z-index: 4;
        overflow: auto;
        top: 0px;
        left: -275px;
        width: 300px;
        opacity: 0;
        padding: 20px 0px;
        height: 100%;
        background-color: lightblue;/*Color de fondo caja desplegable*/
        color: #000000;/*Color Letras caja desplegable*/
        transition: all 250ms;
    }

    #box.active {
        left: 0px;
        opacity: 1;
    }

    #items {
        position: relative;
        top: 50%;
        -webkit-transform: translateY(-50%);
        transform: translateY(-50%);
    }

    #items .footer{
        position: relative;
        top: 100%;
        background-color: red;


    }

    #items .item {
        position: relative;
        cursor: pointer;
        font-size: 1.5em;
        padding: 10px 25px;
        -webkit-transition: all 250ms;
        transition: all 250ms;
    }
    #items .item:hover {
        background-color: rgba(52, 56, 56, 0.2);
    }









</style>



<div id="page-wrapper" class="cargador">

    <div id="listausuarios" class="">
        <?php require 'admin/userlist.php' ?>
    </div>

    <div id="listainvitaciones" class="hidden">
        <?php require 'admin/invitaciones.php' ?>
    </div>

    <div id="listamensajes" class="hidden">
        <?php require 'admin/adminmail.php' ?>
    </div>

    <div id="listareportes" class="hidden">
        <?php require 'admin/buglist.php' ?>
    </div>

    <div id="configuracion" class="hidden">
        CONFIGURACION
    </div>








</div>


<div id="btn">
    <div id='top'></div>
    <div id='middle'></div>
    <div id='bottom'></div>
</div>
<div id="box">
    <div id="items">
        <div class="item" id="usuarios"><span class="fa fa-user"></span> Administrar Usuarios</div>
        <div class="item" id="mensajes"><span class="fa fa-envelope"></span> Mensajes</div>
        <div class="item" id="invitaciones"><span class="fa fa-list"></span> Gestor Invitaciones</div>
        <div class="item" id="config"><span class="fa fa-ticket"></span> Generar Invitaciones</div>
        <div class="item" id="bugs"><span class="fa fa-cogs"></span> Bug List</div>
    </div>
</div>

<div id="generainvitaciones" class="modal fade" role="dialog" >
    <div class="modal-dialog" >
        <div class="modal-content" style="background-color: whitesmoke">
            <div class="modal-body">
                <center>
                    <form id="generainvitacion" method="POST">
                        <table border="0" style="width: 90%;">
                            <tr>
                                <td style="width: 20%"><span>Usos</span><input type="number" id="numeroinv" name="numeroinv" max="100" min="1" value="1" class="form-control input-md" placeholder="Nº Invitaciones" style="width: 70px;"></td>
                                <td style="width: 62%"> 
                                    <div class="input-group" style="float: right; padding-top: 18px;">
                                        <div id="radioBtn" class="btn-group">
                                            <a class="btn btn-default btn-md" id="custominv">Personalizada</a>
                                            <a class="btn btn-primary btn-md" id="1inv">Aleatoria</a>
                                        </div>
                                        <input type="text" id="tipoinvitacion" name="tipoinvitacion" class="form-control hidden" placeholder="" value="R">
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"> 
                                    <br>
                                    <div class="input-group" style="width: 100%;">
                                        <input type="text" id="codigoinvitacion" name="custominv" class="form-control input-md" placeholder="" readonly />
                                        <span class="input-group-btn">
                                            <button class="btn-secondary btn btn-info btn-file btn-md" type="button"><span class="fa fa-copy"></span> Copiar</button>
                                        </span>
                                    </div>
                            <br><center><span id="result"></span></center>
                            </td>
                            </tr>
                            <tr>
                                <td colspan="3"><br><center><input type="submit" style="width: 70%;" class="btn btn-md btn-success" value="Generar Invitacion"></center></td>
                            </tr>
                            <tr>
                                <td colspan="3"><center><input type="button" style="width: 70%;" class="btn btn-md btn-danger" value="Cancelar"></center></td>
                            </tr>
                        </table>
                    </form>
                </center>
            </div>
        </div>

    </div>
</div>


<script>


    var sidebarBox = document.querySelector('#box'),
            sidebarBtn = document.querySelector('#btn'),
            pageWrapper = document.querySelector('#page-wrapper');

    sidebarBtn.addEventListener('click', function (event) {
        sidebarBtn.classList.toggle('active');
        sidebarBox.classList.toggle('active');
    });

    pageWrapper.addEventListener('click', function (event) {

        if (sidebarBox.classList.contains('active')) {
            sidebarBtn.classList.remove('active');
            sidebarBox.classList.remove('active');
        }
    });

    $('#inicio').click(function () {

        $('#listausuarios').addClass('hidden');
        $('#listainvitaciones').addClass('hidden');
        $('#main').removeClass('hidden');
        $('#listamensajes').addClass('hidden');
        $('#listareportes').addClass('hidden');
        $('#configuracion').addClass('hidden');
        sidebarBtn.classList.remove('active');
        sidebarBox.classList.remove('active');

    });

    $('#usuarios').click(function () {

        $('#listausuarios').removeClass('hidden');
        $('#listainvitaciones').addClass('hidden');
        $('#main').addClass('hidden');
        $('#listamensajes').addClass('hidden');
        $('#listareportes').addClass('hidden');
        $('#configuracion').addClass('hidden');
        sidebarBtn.classList.remove('active');
        sidebarBox.classList.remove('active');

    });

    $('#mensajes').click(function () {

        $('#listausuarios').addClass('hidden');
        $('#listainvitaciones').addClass('hidden');
        $('#listamensajes').removeClass('hidden');
        $('#listareportes').addClass('hidden');
        $('#configuracion').addClass('hidden');
        $('#main').addClass('hidden');
        sidebarBtn.classList.remove('active');
        sidebarBox.classList.remove('active');


    });

    $('#invitaciones').click(function () {

        $('#listausuarios').addClass('hidden');
        $('#listainvitaciones').removeClass('hidden');
        $('#listamensajes').addClass('hidden');
        $('#listareportes').addClass('hidden');
        $('#configuracion').addClass('hidden');
        $('#main').addClass('hidden');
        sidebarBtn.classList.remove('active');
        sidebarBox.classList.remove('active');

    });

    $('#bugs').click(function () {

        $('#listausuarios').addClass('hidden');
        $('#listainvitaciones').addClass('hidden');
        $('#listamensajes').addClass('hidden');
        $('#listareportes').removeClass('hidden');
        $('#configuracion').addClass('hidden');
        $('#main').addClass('hidden');
        sidebarBtn.classList.remove('active');
        sidebarBox.classList.remove('active');

    });

    $('#config').click(function () {

        $('#generainvitaciones').modal('toggle');
        sidebarBtn.classList.remove('active');
        sidebarBox.classList.remove('active');

    });

    $("#1inv").click(function () {
        $('#custominv').removeClass('btn-primary');
        $('#custominv').addClass('btn-default');
        $('#1inv').addClass('btn-primary');
        $('#1inv').removeClass('btn-default');
        $('#codigoinvitacion').attr('readonly', true);
        $('#codigoinvitacion').val("");
        $('#tipoinvitacion').val('R');
        console.log($('#tipoinvitacion').val());
    });



    $("#custominv").click(function () {
        $('#custominv').removeClass('btn-default');
        $('#custominv').addClass('btn-primary');
        $('#1inv').removeClass('btn-primary');
        $('#1inv').addClass('btn-default');
        $('#codigoinvitacion').removeAttr('readonly');
        $('#tipoinvitacion').val('C');
        console.log($('#tipoinvitacion').val());
    });



    $('#generainvitacion').submit(function () {
        $.ajax({
            type: 'POST',
            url: 'AJAX/funciones/invitaciones/generainvitacion.php',
            data: $(this).serialize(),
            success: function (invr) {
                alert('Invitaciones Generadas');
                $('#result').html(invr);
                console.log(invr);
                $('#configurapagina').modal('toggle');
                bootstrap_alert.warning(invr, 'info', 1500);

            }
        });

        return false;
    });




</script>