<?php
require 'header.php';
?>


<br>
<div class="container">
    <table border="0" style="width:100%;" >
        <tbody>
            <tr>
                <td style="width: 8vw;"><img id="pimage" class="img img-circle" width="100px" height="100px"  src="<?php echo $imgprofile ?>"> </td>
                <td style="padding-left: 10px; vertical-align: bottom; padding-bottom: 10px;">
                    <span id="nombre" style="padding-bottom: 20px;"><?php echo $nombre ?></span> <br>
                    @<?php echo $usuario ?> - <span id="email"><?php echo $email ?></span>
                </td>
            </tr>
        </tbody>
    </table>
    <hr>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a data-toggle="collapse" href="#collapse1">Informacion Personal <b class="caret"></b></a>
                </h4>
            </div>
            <div id="collapse1" class="panel-collapse collapse">
                <div class="panel-body">
                    <form method="POST" id="cambiadatos">
                        <div class="form-group">
                            <label class="control-label">Nombre</label>
                            <input type="text" name="nombre" class="form-control" placeholder="Introduce tu nombre" id="camponombre">
                            <input type="text" name="usuario" class="hidden" value="<?php echo $idu ?>">
                        </div>
                        <div class="form-group">
                            <label class="control-label">Apellidos</label>
                            <input type="text" name="apellidos" class="form-control" placeholder="Introduce tus apellidos" id="campoapellidos">
                        </div>
                        <center>
                            <button type="submit" class="btn btn-success" style="width: 40%">Guardar</button>
                            <button type="button" class="btn btn-warning" style="width: 40%" data-toggle="collapse" href="#collapse1">Cancelar</button>
                        </center>
                    </form>
                </div>
            </div>
        </div>
        <div class="panel-group">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" href="#collapse4">Cambiar Contraseña <b class="caret"></b></a>
                    </h4>
                </div>
                <div id="collapse4" class="panel-collapse collapse">
                    <div class="panel-body">
                        <form method="POST" id="cambiapass">
                            <div class="form-group">
                                <label class="control-label">Contraseña Actual</label>
                                <input type="password" name="antiguapass" class="form-control" placeholder="Introduce la contraseña actual" id="antiguapass">
                                <input type="text" name="usuario" class="hidden" value="<?php echo $idu ?>">
                            </div>
                            <div class="form-group">
                                <label class="control-label">Nueva Contraseña</label>
                                <input type="password" name="nuevapass" class="form-control" placeholder="Introduce la nueva contraseña" id="nuevapass">
                            </div>
                            <div class="form-group">
                                <label class="control-label">Repite Contraseña</label>
                                <input type="password" name="repitenuevapass" class="form-control" placeholder="Repite la nueva contraseña" id="repitenuevapass">
                            </div>
                            <center>
                                <button type="submit" class="btn btn-success" style="width: 40%">Guardar</button>
                                <button type="button" class="btn btn-warning" style="width: 40%" data-toggle="collapse" href="#collapse4">Cancelar</button>
                            </center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel-group">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" href="#collapse2">Cambiar Foto de Perfil <b class="caret"></b></a>
                    </h4>
                </div>
                <div id="collapse2" class="panel-collapse collapse">
                    <div class="panel-body">
                        <!--Formulario para cambiar la foto de perfil-->
                        <form method="POST" id="cambiafoto">
                            <div class="form-group">
                                <br>
                                <center><img src="<?php echo $imgprofile ?>" height="200px" width="200px" id="usuimg"></center>
                            </div>


                            <center>

                                <button class="btn btn-info btn-file btn-md" style="width: 240px;" type="button" >Selecionar Archivo<input accept="image/*" type="file" id="userimage" name="userimage"></button><br><br>
                                <button type="submit" class="btn btn-warning" style="width: 240px" >Guardar</button>

                            </center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel-group">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a id="cmail" data-toggle="collapse" href="#collapse3">Correo Electronico <b class="caret"></b></a>
                    </h4>
                </div>
                <div id="collapse3" class="panel-collapse collapse">
                    <div class="panel-body">
                        <!--Formulario para cambiar correo electronico-->
                        <form method="POST" id="cambiamail">
                            <div class="form-group">
                                <label class="control-label">Nuevo Correo Electronico</label>
                                <input type="text" name="nuevomail" class="form-control" placeholder="Introduce la nueva direccion de correo" id="nuevomail">
                                <span id="chivatomail" style="padding: 0px;"></span>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Confirma Correo Electronico</label>
                                <input type="text" name="repitenuevomail" class="form-control" placeholder="Confirma la nueva direccion de correo" id="repitenuevomail">
                            </div>
                            <center>
                                <button type="submit" class="btn btn-success" style="width: 40%">Guardar</button>
                                <button type="button" class="btn btn-warning" style="width: 40%" data-toggle="collapse" href="#collapse3">Cancelar</button>
                            </center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel-group">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" href="#collapse5">Avanzado <b class="caret"></b></a>
                    </h4>
                </div>
                <div id="collapse5" class="panel-collapse collapse">
                    <div class="panel-body">

                        <center><button type="button" id="delmyaccount" class="btn btn-danger btn-lg disabled" alt="proximamente" >Borrar mi cuenta</button></center>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">

        $('#cambiadatos').submit(function () {
            $.ajax({
                type: 'POST',
                url: 'AJAX/funciones/edituser/editdata.php',
                data: $(this).serialize(),
                success: function (priv) {
                    bootstrap_alert.warning('Nombre cambiado correctamente', 'warning', 1500);
                    $('#nombre').html(priv);
                }
            });
            return false;
        });

        $('#cambiapass').submit(function () {
            $.ajax({
                type: 'POST',
                url: 'AJAX/funciones/edituser/editpass.php',
                data: $(this).serialize(),
                success: function (priv) {
                    bootstrap_alert.warning(priv, 'warning', 1500);
                }
            });
            return false;
        });

        $('#cambiamail').submit(function () {

            if ($('#nuevomail').val() !== "") {
                $.ajax({
                    type: 'POST',
                    url: 'AJAX/funciones/edituser/editmail.php',
                    data: $(this).serialize(),
                    success: function (priv) {
                        $('#email').html(priv);
                        bootstrap_alert.warning('Correo electronico actualizado correcamente', 'warning', 1500);
                    }
                });
            } else {

                console.log('Mail Vacio');
                $('#cmail').trigger("click");


            }
            return false;
        });

        $('#cambiafoto').submit(function () {
            var formData = new FormData($(this)[0]);
            $.ajax({
                type: 'POST',
                url: 'AJAX/funciones/edituser/editpic.php',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function (priv) {
                    bootstrap_alert.warning('Foto de perfil cambiada correctamente', 'warning', 1500);
                    alert(priv);

                }
            });
            return false;
        });

        $("#userimage").change(function () {
            $("[for=file]").html(this.files[0].name);
            $("#usuimg").attr("src", URL.createObjectURL(this.files[0]));
        });

        $('#nuevomail').focusout(function () {
            var emil = $('#nuevomail').val();
            if ($('#nuevomail').val() !== "") {
                $('#nuevomail').filter(function () {
                    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                    if (!emailReg.test(emil)) {
                        console.log('Formato Email No Valido');
                        $('#chivatomail').html('Introduzca un email valido');
                    } else {
                        $.ajax({
                            type: 'POST',
                            url: 'AJAX/funciones/compruebamail.php',
                            data: 'checkmail=' + $('#nuevomail').val(),
                            success: function (data) {
                                console.log('Mail ' + data);
                                if (data === 'Ocupado') {
                                    $('#reg').attr('type', 'button');
                                    $('#reg').addClass('disabled');
                                    $('#chivatomail').html('El mail introducido esta ocupado');
                                } else if (data === 'Disponible') {
                                    $('#reg').attr('type', 'submit');
                                    $('#reg').removeClass('disabled');
                                    $('#chivatomail').html('');

                                }
                            }
                        });
                    }
                });
            } else {

                console.log('mail vacio');

            }
        });


    </script>