<?php require ('header.php'); ?>


<style type = "text/css">

    .btn-file {
        position: relative;
        overflow: hidden;
    }
    .btn-file input[type=file] {
        position: absolute;
        top: 0;
        right: 0;
        min-width: 100%;
        min-height: 100%;
        font-size: 100px;
        text-align: right;
        filter: alpha(opacity=0);
        opacity: 0;
        outline: none;
        background: white;
        cursor: inherit;
        display: block;
    }

    progress {
        height: 30px;
        width: 100%;
    }

</style>


<div class = "container">


    <div style="width: 100%; margin-top: 30vh;">
        <center>
            <form id="upload_form" method="POST">
                <div class="input-group">
                    <span class="input-group-btn">
                        <button class="btn-secondary btn btn-info btn-file btn-lg" type="button">Selecionar Archivo<input type="file" id="file1" name="file1"></button>
                    </span>
                    <input type="text" id="nombrefichero" class="form-control input-lg" placeholder="Ningun archivo seleccionado" readonly="" >
                </div>
                <br>
                <center>
                    <div class="input-group">
                        <div id="radioBtn" class="btn-group">
                            <a class="btn btn-default btn-lg" id="fpublic">Publico</a>
                            <a class="btn btn-primary btn-lg" id="fprivate">Privado</a>
                        </div>
                        <input type="hidden" name="pruebasfichero" id="vfichero" value="1">
                    </div>
                </center>
                <br>
                <input type="submit" style="width: 100%;" class="btn btn-lg btn-success" value="Subir Archivo">
            </form>
            <progress id="barrapro" value="0" max="100" class="hidden"></progress>
        </center>
    </div>

</div>




</body>


<script>


    $("#file1").change(function () {
        var ruta = this.value;
        var filename = ruta.replace(/^.*\\/, "");
        $('#nombrefichero').val(filename);
        $('#barrapro').removeClass('hidden');
    });

    $('#upload_form').submit(function () {
        var formData = new FormData($(this)[0]);
        $.ajax({
            method: 'POST',
            url: 'fileuploader.php',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (test) {

                bootstrap_alert.warning(test, 'info', 10000);
                $('#barrapro').val(0);
                $("#file1").val(null);
                $('#nombrefichero').val(null);

            },
            error: function () { },
            progress: function (e) {
                var pct = (e.loaded / e.total) * 100;
                if (pct <= 100) {
                    console.log('chivato % ' + Math.round(pct));
                    $('#barrapro').val(pct);
                }

            }
        });
        return false;
    });

    $("#fpublic").click(function () {
        $('#fprivate').removeClass('btn-primary');
        $('#fprivate').addClass('btn-default');
        $('#fpublic').addClass('btn-primary');
        $('#fpublic').removeClass('btn-default');
        $('#vfichero').val('0');
        console.log($('#vfichero').val());
    });

    $("#fprivate").click(function () {
        $('#fprivate').removeClass('btn-default');
        $('#fprivate').addClass('btn-primary');
        $('#fpublic').removeClass('btn-primary');
        $('#fpublic').addClass('btn-default');
        $('#vfichero').val('1');
        console.log($('#vfichero').val());
    });




</script>


</html>