<?php
require 'connect.php';
require 'librerias.php';

$url = $_GET['url'];

$consulta = "SELECT * FROM uploads where url='$url' and hidden=0";

$consultafichero = mysqli_query($connection, $consulta) or die(mysqli_error($connection));

$numero = mysqli_num_rows($consultafichero);

while ($row = mysqli_fetch_array($consultafichero)) {

    $nombreficheros = $row['filename'];
    $tipofichero = $row['filetype'];
    $size = $row['filesize'];
    $owner = $row['owner'];
    $route = $row['route'];
}

function formatSizeUnits($size) {
    if ($size >= 1073741824) {
        $tamaño = number_format($size / 1073741824, 2) . ' GB';
    } elseif ($size >= 1048576) {
        $tamaño = number_format($size / 1048576, 2) . ' MB';
    } elseif ($size >= 1024) {
        $tamaño = number_format($size / 1024, 2) . ' kB';
    } elseif ($size > 1) {
        $tamaño = $size . ' bytes';
    } elseif ($size == 1) {
        $tamaño = $size . ' byte';
    } else {
        $tamaño = '0 size';
    }
    return $tamaño;
}
?>


<?php require 'header2.php' ?>


<style type="text/css">

    .footer {
        position:fixed;
        left:0px;
        bottom:0px;
        height:30px;
        width:100%;
        background-color: #0c84e4;
        border-color: #3174b0;
    }

    .marca{

        float: right;
        margin-right: 20px;
        margin-top: 5px;


    }

    .links{

        float: left;
        margin-left: 20px;
        margin-top: 5px;
        text-decoration: none;


    }

    body{
        background-color: #00e3ff

    }

</style>

<!--CONTENIDO-->

<div class="container">
    <?php if ($numero > 0) { ?>
        <table style="width: 100%; background-color: lightblue; margin-top: 30vh" border="0" >
            <tr>
                <td align="center" style="width: 10%;" colspan="3"><img src="resources/iconfiles/<?php echo $tipofichero ?>.png" width="100" height="100"></td>
            </tr>
            <tr><td colspan="3">&nbsp;</td></tr>
            <tr>
                <td align="center" style="vertical-align:bottom;">&nbsp;&nbsp;<?php echo $nombreficheros ?>&nbsp;&nbsp;|&nbsp;&nbsp;<?php echo formatSizeUnits($size) ?></td>
            </tr>
            <tr><td colspan="3">&nbsp;</td></tr>
            <tr>
                <td colspan="3">
                    <table style="width: 50%;" border="0" align="center">
                        <tr>
                            <td style="width: 30%;" align="center"><button class="btn btn-primary" ><a href="<?php echo $route ?>" download="" style="text-decoration:none;color:white;">DESCARGAR</a></button></td>
                            <td style="width: 30%;" align="center">&nbsp;</td>
                            <td style="width: 30%;" align="center"><button class="btn btn-default">ONDESK SYNC</button></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    <?php } else { ?>
        <table style="width: 80vw; background-color: lightblue; margin-top: 20vh" border="0" align="center" >
            <tr>
                <td align="center" style="width: 10%;" colspan="3"><img src="resources/iconfiles/error.png" width="100" height="100"></td>
            </tr>
            <tr><td colspan="3">&nbsp;</td></tr>
            <tr>
                <td align="center" style="vertical-align:bottom;">
                    <b>El archivo solicitado no se encuentra disponible</b><br><br>
                    Puede que el enlace sea incorrecto, sea privado o el usuario haya borrado el fichero
                </td>
            </tr>
            <tr><td colspan="3">&nbsp;</td></tr>
            <tr>
                <td colspan="3">
                    <table style="width: 50%;" border="0" align="center">
                        <tr>
                            <td align="center" colspan="3"><button style="width: 100%;" class="btn btn-primary" ><a href="index.php" style="text-decoration:none;color:white;">VOLVER</a></button></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    <?php } ?>

</div>



<!--FOOTER-->
<div class="footer">

    <span class="links">

        <a style="color: black; " href="#" alt="terminos de uso">Terminos de Uso</a>
        |
        <a style="color: black; " href="#" alt="licencia de uso">Licencia</a>
        |
        <a style="color: black; " href="#" alt="contacto">Contacto</a>


    </span>

    <span class="marca" style="color: black;">

        OnDesk 2017 <span class="fa fa-creative-commons"></span>

    </span>




</div>