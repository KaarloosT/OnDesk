<?php
session_start();
require_once('connect.php');



if (isset($_SESSION['usuario'])) {



    $username = $_SESSION['usuario'];

    $consulta = "SELECT * FROM user where usuario='$username'";

    $resultadousuario = mysqli_query($connection, $consulta) or die(mysqli_error($connection));

    while ($row = mysqli_fetch_array($resultadousuario)) {

        $nombre = $row["name"];
        $usuario = $row["usuario"];
        $email = $row["email"];
        $account = $row["admin"];
        $fecharegistro = $row["fecharegistro"];
        $imgprofile = $row["profileimg"];
    }
    ?>


    <?php require ('header.php'); ?>


    <style type = "text/css">

        .btn-file {
            position: relative;
            overflow: hidden;
        }
        .btn-file input[type=file] {
            position: absolute;
            top: 0;
            right: 0;
            min-width: 100%;
            min-height: 100%;
            font-size: 100px;
            text-align: right;
            filter: alpha(opacity=0);
            opacity: 0;
            outline: none;
            background: white;
            cursor: inherit;
            display: block;
        }

        progress {

            height: 30px;
            width: 100%;
        }



    </style>


    <div class = "content">



        <div class = "table-responsive" style="width: 100%;">
            <table class = "table table-striped">

                <tr>
                    <th class="col-xs-8 col-md-6"><center>Nombre</center></th><!--Nombre del archivo -->
                <th class="hidden-xs col-md-1"><center>Tamaño</center></th><!--Tamaño del fichero -->
                <th class="hidden-xs col-md-1"><center>Tipo fichero</center></th><!--Extension del fichero -->
                <th class="hidden-xs col-md-1"><center>Fecha</center></th><!--Fecha Subida de archivo -->
                <th class="hidden-xs col-md-1"><center>Visibilidad</center></th><!--Visibilidad Publica del fichero-->
                <th class="col-xs-4 col-md-2"><center>Acciones</center></th><!--Acciones sobre el fichero-->
                </tr>


                <?php

                function formatSizeUnits($size) {
                    if ($size >= 1073741824) {
                        $tamaño = number_format($size / 1073741824, 2) . ' GB';
                    } elseif ($size >= 1048576) {
                        $tamaño = number_format($size / 1048576, 2) . ' MB';
                    } elseif ($size >= 1024) {
                        $tamaño = number_format($size / 1024, 2) . ' kB';
                    } elseif ($size > 1) {
                        $tamaño = $size . ' bytes';
                    } elseif ($size == 1) {
                        $tamaño = $size . ' byte';
                    } else {
                        $tamaño = '0 size';
                    }
                    return $tamaño;
                }

                $sql = mysqli_query($connection, "SELECT * FROM uploads WHERE owner='$username'");

                if (mysqli_num_rows($sql) == 0) {
                    echo '<tr><td colspan="8">No has subido ningun archivo, prueba a subir uno desde <a href="upload.php">aqui</a></td></tr>';
                } else {
                    $no = 1;
                    while ($row = mysqli_fetch_assoc($sql)) {
                        ?>

                        <tr id="file<?php echo $row['ID']; ?>">
                            <td id="name<?php echo $row['ID']; ?>"><?php echo $row['filename']; ?></td>
                            <td class="hidden-xs"><center><?php echo formatSizeUnits($row['filesize']) ?></center></td>
                        <td class="hidden-xs"><center id="tipo"><?php echo $row['filetype']; ?></center></td>
                        <td class="hidden-xs"><center><?php echo $row['fechasubida']; ?></center></td>
                        <td class="hidden-xs">
                        <center>
                            <?php if ($row['hidden'] == '1') { ?>
                                <output><span class="label label-danger" id="state<?php echo $row['ID']; ?>" style="padding: 5px;" >Privado</span></output>
                            <?php } else { ?>
                                <output><span class="label label-info" id="state<?php echo $row['ID']; ?>" style="padding: 5px;">Publico</span></output>
                                <?php
                            }
                            ?>
                        </center>
                        </td>
                        <td class="hidden" id="link<?php echo $row['ID']; ?>"><?php echo $row['url']; ?></td>
                        <td>
                        <center>

                            <a id="<?php echo $row['ID']; ?>" onclick="muestra(this.id)" title="Editar Propiedades" class="btn btn-primary btn-md"><span class="fa fa-pencil-square-o" aria-hidden="true"></span></a>

                            <a id="<?php echo $row['ID']; ?>" onclick="enlace(this.id)" title="Obtener Enlance" class="btn btn-warning btn-md"><span class="fa fa-link" aria-hidden="true"></span></a>

                            <a id="des<?php echo $row['ID']; ?>" href="<?php echo $row['route']; ?>" class="btn btn-success btn-md" download=""><span class="fa fa-download" aria-hidden="true"></span></a>

                            <button id="<?php echo $row['ID']; ?>" class="btn btn-danger  btn-md" onclick="confirmaborrado(this.id);" value="fichero"><span class="fa fa-trash" aria-hidden="true"></span></button>
                        </center>
                        </td>
                        </tr>


                        <?php
                        $no++;
                    }
                }
                ?>   
            </table>

        </div>


        <!--Modificar algunos datos del archivo-->
        <div id = "ShowFileData" class = "modal fade" role = "dialog" style="height: 500px; padding-top: 5%; overflow-y:hidden; overflow-x:hidden;">
            <div class = "modal-dialog">
                <div class = "modal-content">
                    <form method="" id="modfile">

                        <div class = "modal-body">
                            <div class="form-group">
                                <label for="name" class="cols-sm-2 control-label">Nombre del Fichero</label>
                                <div class="cols-sm-10">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-file-o" aria-hidden="true"></i></span>
                                        <input type="text" class="form-control input-lg" name="filename" id="sname" required/>
                                        <input type="hidden" name="lastname" id="lastname">
                                        <input type="hidden" name="filext" id="extension">
                                        <input type="hidden" name="nomuser" value="<?php echo $usuario ?>">
                                        <input type="hidden" class="form-control input-lg hidden" name="filenum" id="sid" />
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="cols-sm-2 control-label">Visibilidad del Fichero</label><br>
                                <center>
                                    <div class="input-group">
                                        <div id="radioBtn" class="btn-group">
                                            <a class="btn btn-primary btn-lg" id="fpublic">Publico</a>
                                            <a class="btn btn-default btn-lg" id="fprivate">Privado</a>
                                        </div>
                                        <input type="hidden" name="privacy" id="visible">
                                    </div>
                                </center>
                            </div>


                            <br>
                            <center><button type="submit" id="reg" name="inicio" class="btn btn-success btn-lg" style="width: 49%;">Guardar Cambios</button>
                                <a href="#" class="btn btn-danger btn-lg" data-dismiss="modal" role="button" style="width: 49%;">Cancelar</a></center>
                        </div>
                    </form>

                </div>
            </div>
        </div>
        <!--Modificar algunos datos del archivo-->

        <!--Mostramos el link y permitimos copiarlo al portapapeles conn un boton-->
        <div id = "ShowFileLink" class = "modal fade" role = "dialog" style="height: 350px; overflow-y:hidden; overflow-x:hidden;">
            <div class = "modal-dialog">
                <div class = "modal-content">
                    <div class = "modal-body">
                        <div class="form-group">
                            <div class="cols-sm-10">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-link" aria-hidden="true"></i></span>
                                    <input type="text" class="form-control input-lg" id="slink" name="" readonly=""/>
                                </div>
                            </div>
                        </div>
                        <button name="inicio" class="btn btn-success btn-md" data-clipboard-action="copy" data-clipboard-target="#slink" style="width: 100%; padding: 10px;" onclick="copia()">Copiar al Portapapeles</button>
                        <a href="#" class="btn btn-danger btn-md" data-dismiss="modal" role="button" style="width: 100%; padding: 10px;">Cancelar</a>
                    </div>
                </div>
            </div>
        </div>
        <!--Mostramos el link y permitimos copiarlo al portapapeles conn un boton-->

        <!--Confirmacion de que quiere borrar el fichero-->
        <div id = "ConfirmDelete" class = "modal fade" role = "dialog" style="height: 500px; padding-top: 10%; overflow-y:hidden; overflow-x:hidden;">
            <div class = "modal-dialog">
                <div class = "modal-content">
                    <form method="POST" id="delfile">

                        <center><h4>Estas seguro?</h4></center>

                        <center><img src="resources/images/pregunta.PNG"></center>

                        <center><h4>Esta accion no se puede deshacer</h4></center>

                        <input type="hidden" id="borrafichero" name="borrafichero" class="">

                        <br>
                        <center><button type="submit" id="reg" name="inicio" class="btn btn-danger btn-md" style="width: 30%; padding: 10px;">Borrar</button>
                            <a href="#" class="btn btn-warning btn-md" data-dismiss="modal" role="button" style="width: 30%; padding: 10px;">Cancelar</a></center>
                </div>
                </form>

            </div>
        </div>
        <!--Confirmacion de que quiere borrar el fichero-->
    </div>


    </body>


    <script>


        //Inicializamos la libreria Clipboard
        var clipboard = new Clipboard('.btn');

        clipboard.on('success', function (e) {

            e.clearSelection();
            $('#ShowFileLink').modal('toggle');
            bootstrap_alert.warning('Enlace Copiado al portapapeles', 'info', 1500);


        });

        function muestra(archivoid) {

            var nombre = $('#name' + archivoid).html();
            var estado = $('#state' + archivoid).html();



            $('#ShowFileData').modal({show: true});

            $('#sname').val(nombre);

            var ext = nombre.split('.').pop();

            $('#extension').val(ext);

            $('#lastname').val(nombre);

            if (estado === 'Privado') {

                $('#visible').val('1');
                $("#fprivate").trigger("click");

            } else {

                $('#visible').val('0');
                $("#fpublic").trigger("click");

            }


            $('#sid').val(archivoid);

        }

        function enlace(enlaceid) {

            var enlace = $('#link' + enlaceid).html();

            $('#ShowFileLink').modal({show: true});

            var fenlace = "www.ondesk.eu/download.php?url=" + enlace;

            $('#slink').val(fenlace);



        }

        function confirmaborrado(borraid) {

            $('#borrafichero').val(borraid);
            $('#ConfirmDelete').modal({show: true});

        }

        $('#modfile').submit(function () {

            var num = $('#sid').val();
            var tipo = $('#extension').val();
            var nombre = $('#sname').val();
            var tmp = nombre.split("."+tipo);
            
            var final = tmp[0] + '.' + tipo;
            $.ajax({
                type: 'POST',
                url: 'AJAX/funciones/ficheros/editfile.php',
                data: $(this).serialize(),
                success: function (priv) {
                    //alert('Archivo Modificado');
                    $('#ShowFileData').modal('toggle');
                    $('#name' + num).html(final);
                    $('#des' + num).prop('href', 'filesuploaded/<?php echo $usuario ?>/' + final);
                    if (priv === 'Publico') {

                        $('#state' + num).removeClass('label-danger');
                        $('#state' + num).addClass('label-info');
                        $('#state' + num).html(priv);

                    } else {

                        $('#state' + num).removeClass('label-info');
                        $('#state' + num).addClass('label-danger');
                        $('#state' + num).html(priv);
                    }
                    bootstrap_alert.warning('Fichero Modificado Correctamente', 'success', 1500);
                }
            });

            return false;
        });


        $('#delfile').submit(function () {
            $.ajax({
                type: 'POST',
                url: 'AJAX/funciones/ficheros/deletefile.php',
                data: $(this).serialize(),
                success: function (del) {
                    //                    alert('Funcion Ejectuada');
                    //                    alert(del);
                    $('#file' + del).addClass('hidden');
                    $('#ConfirmDelete').modal('toggle');
                    bootstrap_alert.warning('Fichero eliminado', 'info', 1500);
                }
            });

            return false;
        });



        $("#fpublic").click(function () {
            $('#fprivate').removeClass('btn-primary');
            $('#fprivate').addClass('btn-default');
            $('#fpublic').addClass('btn-primary');
            $('#fpublic').removeClass('btn-default');
            $('#visible').val('0');

        });

        $("#fprivate").click(function () {
            $('#fprivate').removeClass('btn-default');
            $('#fprivate').addClass('btn-primary');
            $('#fpublic').removeClass('btn-primary');
            $('#fpublic').addClass('btn-default');
            $('#visible').val('1');
        });


    </script>


    </html>
    <?php
} else {

    header('Location: index.php');
}
?>