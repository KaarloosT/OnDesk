<?php
require('connect.php');
session_start();


if (isset($_SESSION['usuario'])) {

    header('Location: archivos-bs.php');
} else {

    if (isset($_POST['inicio'])) {

        $username = $_POST['username'];
        $password = SHA1($_POST['password']);

        $query = "SELECT * FROM user WHERE usuario='$username'";
        $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

        while ($row = mysqli_fetch_array($result)) {

            $account = $row["admin"];
            $usuario = $row["usuario"];
            $passwd = $row["password"];
            $estado = $row["activo"];
        }

        if ($login != 'C' || $account === 'Admin') {

            if ($estado == 'DEC') {

                header('Location: cuentabloqueada.php');
                
            } else {
                if ($username == $usuario && $password == $passwd) {

                    $_SESSION['usuario'] = $username;

                }

                if (isset($_SESSION['usuario'])) {

                    header('Location: archivos-bs.php');
                
                }
            }
        } else {

            $_SESSION = array();
            session_destroy();
            header('Location: loginscerrados.php');
        }
    }
}
?>
<html>

    <?php require 'librerias.php'; ?>
    <style type="text/css">

        .footer {
            position:fixed;
            left:0px;
            bottom:0px;
            height:30px;
            width:100%;
            background-color: #ffffff;
            border-color: #3174b0;
        }

        .links{

            float: left;
            margin-left: 20px;
            margin-top: 5px;
            text-decoration: none;


        }

        .marca{

            float: right;
            margin-right: 20px;
            margin-top: 5px;


        }
    </style>


    <div class="container">
        <form method="POST">
            <center><img src="resources/images/logo.png" style="margin-top: 25vh;" class="img img-responsive"></center>
            <br>
            <br>
            <div class="form-group">
                <div class="cols-lg-10">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                        <input type="text" class="form-control input-lg" name="username" id="name"  placeholder="Usuario"/>
                    </div>
                </div>
                <label for="name" id="username" class="cols-sm-2 control-label"></label>
            </div>

            <div class="form-group">
                <div class="cols-lg-10">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-lock" aria-hidden="true"></i></span>
                        <input id="pass" type="password" class="form-control input-lg" name="password" placeholder="Contrase&ntilde;a" onblur="compruebapass()"/>
                        <span class="input-group-addon" id="showpass"><i class="fa fa-eye" id="iconpass"  aria-hidden="true"></i></span>
                    </div>
                </div>
                <label for="email" id="password" class="cols-sm-2 control-label"></label>
            </div>
            <br>
            <button type="submit" id="reg" name="inicio" class="btn btn-success btn-md" style="width: 100%; padding: 10px;">Iniciar Sesion</button>
            <br>
            <br>
            <a href="registro.php" class="btn btn-success btn-md" role="button" style="width: 100%; padding: 10px;">Registrate</a>
        </form>
    </div>

    <div class="footer">

        <span class="links">

            <a style="color: black; " href="" data-toggle="modal" data-target="#terminos" alt="terminos de uso">Terminos de Uso</a>
            |
            <a style="color: black; " href="#" alt="licencia de uso">Licencia</a>
            |
            <a style="color: black; " href="contactfrom.php" alt="contacto">Contacto</a>


        </span>

        <span class="marca" style="color: black;">

            OnDesk 2017 <span class="fa fa-creative-commons"></span>

        </span>




    </div>

    <div id="terminos" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Terminos y condiciones OnDesk</h4>
                </div>
                <div class="modal-body"> 
                    <b>INFORMACIÓN RELEVANTE</b><br><br>
                    El usuario puede elegir y cambiar la clave para su acceso de administración de la cuenta en cualquier momento, en caso de que se haya registrado. Ondesk.eu no asume la responsabilidad en caso de que el usuario entregue dicha clave a terceras personas
                    Ondesk.eu no se hace responsable de la legitimidad de los ficheros que los usuarios almacenen en la plataforma web<br><br>
                    OnDesk.eu, se reserva el derecho de realizar modificaciones en los terminos y condiciones en cualquier momento<br><br>
                    <b>USO NO AUTORIZADO</b><br><br>
                    En caso de que aplique el usuario tiene totalmente prohibido comercializar parcial o completamente fragmentos de código de OnDesk.eu<br><br>
                    <b>PRIVACIDAD</b><br><br>
                    ondesk.eu garantiza que la información personal que usted envía cuenta con la seguridad necesaria. Los datos ingresados por usuario o en el caso de requerir una validación de los pedidos no serán entregados a terceros, salvo que deba ser revelada en cumplimiento a una orden judicial o requerimientos legales.
                    La suscripción a boletines de correos electrónicos publicitarios es voluntaria y podría ser seleccionada al momento de crear su cuenta.
                    OnDesk Online Services reserva los derechos de cambiar o de modificar estos términos sin previo aviso.<br><br>
                    <b>BORRAR MI CUENTA</b><br><br>
                    ondesk.eu, en el momento de eliminar la cuenta por peticion del usuario o por otros motivos eliminara los ficheros del usuario que se encuentren en estado publico, por otra parte
                    todos los ficheros privados que se hayan subido, seran eliminados completamente del sistema de almacenamiento

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>
</body>
</html>


<script>




</script>
